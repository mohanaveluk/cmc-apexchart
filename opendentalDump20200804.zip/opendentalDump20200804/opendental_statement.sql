-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `statement`
--

DROP TABLE IF EXISTS `statement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `statement` (
  `StatementNum` bigint NOT NULL AUTO_INCREMENT,
  `PatNum` bigint NOT NULL,
  `DateSent` date NOT NULL,
  `DateRangeFrom` date NOT NULL,
  `DateRangeTo` date NOT NULL,
  `Note` text,
  `NoteBold` text,
  `Mode_` tinyint unsigned NOT NULL,
  `HidePayment` tinyint(1) NOT NULL,
  `SinglePatient` tinyint(1) NOT NULL,
  `Intermingled` tinyint(1) NOT NULL,
  `IsSent` tinyint(1) NOT NULL,
  `DocNum` bigint NOT NULL,
  `DateTStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IsReceipt` tinyint NOT NULL,
  `IsInvoice` tinyint NOT NULL,
  `IsInvoiceCopy` tinyint NOT NULL,
  `EmailSubject` varchar(255) NOT NULL,
  `EmailBody` mediumtext NOT NULL,
  `SuperFamily` bigint NOT NULL,
  `IsBalValid` tinyint NOT NULL,
  `InsEst` double NOT NULL,
  `BalTotal` double NOT NULL,
  `StatementType` varchar(50) NOT NULL,
  `ShortGUID` varchar(30) NOT NULL,
  `StatementShortURL` varchar(50) NOT NULL,
  `StatementURL` varchar(255) NOT NULL,
  `SmsSendStatus` tinyint NOT NULL,
  PRIMARY KEY (`StatementNum`),
  KEY `PatNum` (`PatNum`),
  KEY `DocNum` (`DocNum`),
  KEY `SuperFamModeDateSent` (`SuperFamily`,`Mode_`,`DateSent`),
  KEY `ShortGUID` (`ShortGUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statement`
--

LOCK TABLES `statement` WRITE;
/*!40000 ALTER TABLE `statement` DISABLE KEYS */;
/*!40000 ALTER TABLE `statement` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:19:54
