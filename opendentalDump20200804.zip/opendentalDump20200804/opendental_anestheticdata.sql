-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anestheticdata`
--

DROP TABLE IF EXISTS `anestheticdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `anestheticdata` (
  `AnestheticDataNum` int NOT NULL AUTO_INCREMENT,
  `AnestheticRecordNum` int NOT NULL,
  `AnesthOpen` char(32) DEFAULT NULL,
  `AnesthClose` char(32) DEFAULT NULL,
  `SurgOpen` char(32) DEFAULT NULL,
  `SurgClose` char(32) DEFAULT NULL,
  `Anesthetist` char(32) DEFAULT NULL,
  `Surgeon` char(32) DEFAULT NULL,
  `Asst` char(32) DEFAULT NULL,
  `Circulator` char(32) DEFAULT NULL,
  `VSMName` char(20) DEFAULT NULL,
  `VSMSerNum` char(20) DEFAULT NULL,
  `ASA` char(3) DEFAULT NULL,
  `ASA_EModifier` char(1) DEFAULT NULL,
  `O2LMin` smallint DEFAULT NULL,
  `N2OLMin` smallint DEFAULT NULL,
  `RteNasCan` tinyint(1) DEFAULT NULL,
  `RteNasHood` tinyint(1) DEFAULT NULL,
  `RteETT` tinyint(1) DEFAULT NULL,
  `MedRouteIVCath` tinyint(1) DEFAULT NULL,
  `MedRouteIVButtFly` tinyint(1) DEFAULT NULL,
  `MedRouteIM` tinyint(1) DEFAULT NULL,
  `MedRoutePO` tinyint(1) DEFAULT NULL,
  `MedRouteNasal` tinyint(1) DEFAULT NULL,
  `MedRouteRectal` tinyint(1) DEFAULT NULL,
  `IVSite` char(20) DEFAULT NULL,
  `IVGauge` smallint DEFAULT NULL,
  `IVSideR` smallint DEFAULT NULL,
  `IVSideL` smallint DEFAULT NULL,
  `IVAtt` smallint DEFAULT NULL,
  `IVF` char(20) DEFAULT NULL,
  `IVFVol` float DEFAULT NULL,
  `MonBP` tinyint(1) DEFAULT NULL,
  `MonSpO2` tinyint(1) DEFAULT NULL,
  `MonEtCO2` tinyint(1) DEFAULT NULL,
  `MonTemp` tinyint(1) DEFAULT NULL,
  `MonPrecordial` tinyint(1) DEFAULT NULL,
  `MonEKG` tinyint(1) DEFAULT NULL,
  `Notes` text,
  `PatWgt` smallint DEFAULT NULL,
  `WgtUnitsLbs` tinyint(1) DEFAULT NULL,
  `WgtUnitsKgs` tinyint(1) DEFAULT NULL,
  `PatHgt` smallint DEFAULT NULL,
  `EscortName` char(32) DEFAULT NULL,
  `EscortCellNum` char(13) DEFAULT NULL,
  `EscortRel` char(16) DEFAULT NULL,
  `NPOTime` char(5) DEFAULT NULL,
  `HgtUnitsIn` tinyint(1) DEFAULT NULL,
  `HgtUnitsCm` tinyint(1) DEFAULT NULL,
  `Signature` text,
  `SigIsTopaz` tinyint unsigned DEFAULT '0',
  PRIMARY KEY (`AnestheticDataNum`),
  KEY `AnestheticRecordNum` (`AnestheticRecordNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anestheticdata`
--

LOCK TABLES `anestheticdata` WRITE;
/*!40000 ALTER TABLE `anestheticdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `anestheticdata` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:01
