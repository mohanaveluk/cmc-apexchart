-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `claimproc`
--

DROP TABLE IF EXISTS `claimproc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `claimproc` (
  `ClaimProcNum` bigint NOT NULL AUTO_INCREMENT,
  `ProcNum` bigint NOT NULL,
  `ClaimNum` bigint NOT NULL,
  `PatNum` bigint NOT NULL,
  `ProvNum` bigint NOT NULL,
  `FeeBilled` double NOT NULL DEFAULT '0',
  `InsPayEst` double NOT NULL DEFAULT '0',
  `DedApplied` double NOT NULL DEFAULT '0',
  `Status` tinyint unsigned NOT NULL DEFAULT '0',
  `InsPayAmt` double NOT NULL DEFAULT '0',
  `Remarks` varchar(255) DEFAULT '',
  `ClaimPaymentNum` bigint NOT NULL,
  `PlanNum` bigint NOT NULL,
  `DateCP` date NOT NULL DEFAULT '0001-01-01',
  `WriteOff` double NOT NULL DEFAULT '0',
  `CodeSent` varchar(15) DEFAULT '',
  `AllowedOverride` double NOT NULL,
  `Percentage` tinyint NOT NULL DEFAULT '-1',
  `PercentOverride` tinyint NOT NULL DEFAULT '-1',
  `CopayAmt` double NOT NULL DEFAULT '-1',
  `NoBillIns` tinyint unsigned NOT NULL DEFAULT '0',
  `PaidOtherIns` double NOT NULL DEFAULT '-1',
  `BaseEst` double NOT NULL DEFAULT '0',
  `CopayOverride` double NOT NULL DEFAULT '-1',
  `ProcDate` date NOT NULL DEFAULT '0001-01-01',
  `DateEntry` date NOT NULL DEFAULT '0001-01-01',
  `LineNumber` tinyint unsigned NOT NULL,
  `DedEst` double NOT NULL,
  `DedEstOverride` double NOT NULL,
  `InsEstTotal` double NOT NULL,
  `InsEstTotalOverride` double NOT NULL,
  `PaidOtherInsOverride` double NOT NULL,
  `EstimateNote` varchar(255) NOT NULL,
  `WriteOffEst` double NOT NULL,
  `WriteOffEstOverride` double NOT NULL,
  `ClinicNum` bigint NOT NULL,
  `InsSubNum` bigint NOT NULL,
  `PaymentRow` int NOT NULL,
  `PayPlanNum` bigint NOT NULL,
  `ClaimPaymentTracking` bigint NOT NULL,
  `SecUserNumEntry` bigint NOT NULL,
  `SecDateEntry` date NOT NULL DEFAULT '0001-01-01',
  `SecDateTEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DateSuppReceived` date NOT NULL DEFAULT '0001-01-01',
  `DateInsFinalized` date NOT NULL DEFAULT '0001-01-01',
  PRIMARY KEY (`ClaimProcNum`),
  KEY `indexPatNum` (`PatNum`),
  KEY `indexPlanNum` (`PlanNum`),
  KEY `indexClaimNum` (`ClaimNum`),
  KEY `indexProvNum` (`ProvNum`),
  KEY `indexProcNum` (`ProcNum`),
  KEY `indexClaimPaymentNum` (`ClaimPaymentNum`),
  KEY `ClinicNum` (`ClinicNum`),
  KEY `InsSubNum` (`InsSubNum`),
  KEY `Status` (`Status`),
  KEY `PayPlanNum` (`PayPlanNum`),
  KEY `indexCPNSIPA` (`ClaimPaymentNum`,`Status`,`InsPayAmt`),
  KEY `indexPNPD` (`ProvNum`,`ProcDate`),
  KEY `indexPNDCP` (`ProvNum`,`DateCP`),
  KEY `ClaimPaymentTracking` (`ClaimPaymentTracking`),
  KEY `SecUserNumEntry` (`SecUserNumEntry`),
  KEY `indexAcctCov` (`ProcNum`,`PlanNum`,`Status`,`InsPayAmt`,`InsPayEst`,`WriteOff`,`NoBillIns`),
  KEY `DateCP` (`DateCP`),
  KEY `DateSuppReceived` (`DateSuppReceived`),
  KEY `indexOutClaimCovering` (`ClaimNum`,`ClaimPaymentNum`,`InsPayAmt`,`DateCP`),
  KEY `indexAgingCovering` (`Status`,`PatNum`,`DateCP`,`PayPlanNum`,`InsPayAmt`,`WriteOff`,`InsPayEst`,`ProcDate`,`ProcNum`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `claimproc`
--

LOCK TABLES `claimproc` WRITE;
/*!40000 ALTER TABLE `claimproc` DISABLE KEYS */;
INSERT INTO `claimproc` VALUES (1,1,0,1,1,0,0,0,6,0,'',0,5,'0001-01-01',0,'',-1,0,-1,-1,0,0,0,-1,'0001-01-01','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,1,0,0,0,1,'2019-08-09','2019-08-09 23:51:55','0001-01-01','0001-01-01'),(2,3,0,1,1,0,0,0,6,0,'',0,5,'0001-01-01',0,'',-1,0,-1,-1,0,0,0,-1,'0001-01-01','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,1,0,0,0,1,'2019-08-09','2019-08-09 23:51:55','0001-01-01','0001-01-01'),(3,4,0,1,1,0,0,0,6,0,'',0,5,'0001-01-01',0,'',-1,0,-1,-1,0,0,0,-1,'0001-01-01','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,1,0,0,0,1,'2019-08-09','2019-08-09 23:51:56','0001-01-01','0001-01-01'),(4,7,0,1,1,0,0,0,6,0,'',0,5,'0001-01-01',0,'',-1,0,-1,-1,0,0,0,-1,'0001-01-01','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,1,0,0,0,1,'2019-08-09','2019-08-09 23:51:56','0001-01-01','0001-01-01'),(5,11,0,1,1,0,0,0,6,0,'',0,5,'0001-01-01',0,'',-1,0,-1,-1,0,0,0,-1,'0001-01-01','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,1,0,0,0,1,'2019-08-09','2019-08-09 23:51:56','0001-01-01','0001-01-01'),(13,15,0,2,1,0,0,0,6,0,'',0,6,'2019-08-07',0,'',-1,0,-1,-1,0,0,0,-1,'2019-08-07','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,2,0,0,0,1,'2019-08-09','2019-08-09 23:57:08','0001-01-01','0001-01-01'),(15,22,0,5,1,0,375,0,6,0,'',0,7,'2019-08-09',0,'',-1,0,50,-1,0,0,375,-1,'2020-07-05','0001-01-01',0,0,-1,375,-1,-1,'',-1,-1,0,3,0,0,0,1,'2019-08-09','2020-07-05 20:01:32','0001-01-01','0001-01-01'),(16,23,0,5,1,0,375,0,6,0,'',0,7,'2019-08-09',0,'',-1,0,50,-1,0,0,375,-1,'2020-07-05','0001-01-01',0,0,-1,375,-1,-1,'',-1,-1,0,3,0,0,0,1,'2019-08-09','2020-07-05 20:01:32','0001-01-01','0001-01-01'),(17,24,0,5,1,0,375,0,6,0,'',0,7,'2019-08-09',0,'',-1,0,50,-1,0,0,375,-1,'2020-07-05','0001-01-01',0,0,-1,375,-1,-1,'',-1,-1,0,3,0,0,0,1,'2019-08-09','2020-07-05 20:01:32','0001-01-01','0001-01-01'),(18,25,0,3,1,0,375,0,6,0,'',0,8,'2019-08-09',0,'',-1,0,50,-1,0,0,375,-1,'2019-08-09','0001-01-01',0,0,-1,375,-1,-1,'',-1,-1,0,4,0,0,0,1,'2019-08-09','2019-08-10 00:14:38','0001-01-01','0001-01-01'),(21,27,0,3,1,0,0,0,6,0,'',0,8,'2019-08-09',0,'',-1,0,-1,-1,0,0,0,-1,'2019-12-27','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,4,0,0,0,1,'2019-08-09','2019-12-28 01:20:47','0001-01-01','0001-01-01'),(24,30,0,3,1,0,0,0,6,0,'',0,8,'2020-02-23',0,'',-1,0,-1,-1,0,0,0,-1,'2020-02-23','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,4,0,0,0,1,'2020-02-23','2020-02-23 14:48:06','0001-01-01','0001-01-01'),(25,31,0,3,1,0,0,0,6,0,'',0,8,'2020-02-23',0,'',-1,0,-1,-1,0,0,0,-1,'2020-02-23','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,4,0,0,0,1,'2020-02-23','2020-02-23 14:48:06','0001-01-01','0001-01-01'),(27,33,0,5,1,0,0,0,6,0,'',0,7,'2020-02-26',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,3,0,0,0,1,'2020-02-26','2020-07-05 20:01:32','0001-01-01','0001-01-01'),(28,34,0,5,1,0,0,0,6,0,'',0,7,'2020-02-26',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,3,0,0,0,1,'2020-02-26','2020-07-05 20:01:33','0001-01-01','0001-01-01'),(29,35,0,5,1,0,0,0,6,0,'',0,7,'2020-02-26',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,3,0,0,0,1,'2020-02-26','2020-07-05 20:01:33','0001-01-01','0001-01-01'),(30,36,0,5,1,0,0,0,6,0,'',0,7,'2020-02-26',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,3,0,0,0,1,'2020-02-26','2020-07-05 20:01:33','0001-01-01','0001-01-01'),(31,37,0,5,1,0,0,0,6,0,'',0,7,'2020-02-26',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,3,0,0,0,1,'2020-02-26','2020-07-05 20:01:33','0001-01-01','0001-01-01'),(63,75,0,1,1,0,0,0,6,0,'',0,5,'2020-07-05',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,1,0,0,0,1,'2020-07-05','2020-07-05 20:20:36','0001-01-01','0001-01-01'),(64,76,0,1,1,0,0,0,6,0,'',0,5,'2020-07-05',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,1,0,0,0,1,'2020-07-05','2020-07-05 20:20:38','0001-01-01','0001-01-01'),(65,77,0,1,1,0,0,0,6,0,'',0,5,'2020-07-05',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,1,0,0,0,1,'2020-07-05','2020-07-05 20:20:39','0001-01-01','0001-01-01'),(66,78,0,3,1,0,0,0,6,0,'',0,8,'2020-07-05',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,4,0,0,0,1,'2020-07-05','2020-07-05 20:21:13','0001-01-01','0001-01-01'),(70,84,0,2,1,0,0,0,6,0,'',0,6,'2020-07-05',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,2,0,0,0,1,'2020-07-05','2020-07-05 20:23:42','0001-01-01','0001-01-01'),(71,85,0,2,1,0,0,0,6,0,'',0,6,'2020-07-05',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,2,0,0,0,1,'2020-07-05','2020-07-05 20:23:42','0001-01-01','0001-01-01'),(72,86,0,5,1,0,0,0,6,0,'',0,7,'2020-07-05',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,3,0,0,0,1,'2020-07-05','2020-07-05 20:25:16','0001-01-01','0001-01-01'),(73,87,0,5,1,0,0,0,6,0,'',0,7,'2020-07-05',0,'',-1,0,-1,-1,0,0,0,-1,'2020-07-05','0001-01-01',0,0,-1,0,-1,-1,'',-1,-1,0,3,0,0,0,1,'2020-07-05','2020-07-05 20:25:16','0001-01-01','0001-01-01');
/*!40000 ALTER TABLE `claimproc` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:19:53
