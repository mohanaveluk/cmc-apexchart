-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `claim`
--

DROP TABLE IF EXISTS `claim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `claim` (
  `ClaimNum` bigint NOT NULL AUTO_INCREMENT,
  `PatNum` bigint NOT NULL,
  `DateService` date NOT NULL DEFAULT '0001-01-01',
  `DateSent` date NOT NULL DEFAULT '0001-01-01',
  `ClaimStatus` char(1) DEFAULT '',
  `DateReceived` date NOT NULL DEFAULT '0001-01-01',
  `PlanNum` bigint NOT NULL,
  `ProvTreat` bigint NOT NULL,
  `ClaimFee` double NOT NULL DEFAULT '0',
  `InsPayEst` double NOT NULL DEFAULT '0',
  `InsPayAmt` double NOT NULL DEFAULT '0',
  `DedApplied` double NOT NULL DEFAULT '0',
  `PreAuthString` varchar(40) DEFAULT '',
  `IsProsthesis` char(1) DEFAULT '',
  `PriorDate` date NOT NULL DEFAULT '0001-01-01',
  `ReasonUnderPaid` varchar(255) DEFAULT '',
  `ClaimNote` varchar(255) DEFAULT '',
  `ClaimType` varchar(255) DEFAULT '',
  `ProvBill` bigint NOT NULL,
  `ReferringProv` bigint NOT NULL,
  `RefNumString` varchar(40) DEFAULT '',
  `PlaceService` tinyint unsigned NOT NULL DEFAULT '0',
  `AccidentRelated` char(1) DEFAULT '',
  `AccidentDate` date NOT NULL DEFAULT '0001-01-01',
  `AccidentST` varchar(2) DEFAULT '',
  `EmployRelated` tinyint unsigned NOT NULL DEFAULT '0',
  `IsOrtho` tinyint unsigned NOT NULL DEFAULT '0',
  `OrthoRemainM` tinyint unsigned NOT NULL DEFAULT '0',
  `OrthoDate` date NOT NULL DEFAULT '0001-01-01',
  `PatRelat` tinyint unsigned NOT NULL DEFAULT '0',
  `PlanNum2` bigint NOT NULL,
  `PatRelat2` tinyint unsigned NOT NULL DEFAULT '0',
  `WriteOff` double NOT NULL DEFAULT '0',
  `Radiographs` tinyint unsigned NOT NULL DEFAULT '0',
  `ClinicNum` bigint NOT NULL,
  `ClaimForm` bigint NOT NULL,
  `AttachedImages` int NOT NULL,
  `AttachedModels` int NOT NULL,
  `AttachedFlags` varchar(255) DEFAULT NULL,
  `AttachmentID` varchar(255) DEFAULT NULL,
  `CanadianMaterialsForwarded` varchar(10) NOT NULL,
  `CanadianReferralProviderNum` varchar(20) NOT NULL,
  `CanadianReferralReason` tinyint NOT NULL,
  `CanadianIsInitialLower` varchar(5) NOT NULL,
  `CanadianDateInitialLower` date NOT NULL DEFAULT '0001-01-01',
  `CanadianMandProsthMaterial` tinyint NOT NULL,
  `CanadianIsInitialUpper` varchar(5) NOT NULL,
  `CanadianDateInitialUpper` date NOT NULL DEFAULT '0001-01-01',
  `CanadianMaxProsthMaterial` tinyint NOT NULL,
  `InsSubNum` bigint NOT NULL,
  `InsSubNum2` bigint NOT NULL,
  `CanadaTransRefNum` varchar(255) NOT NULL,
  `CanadaEstTreatStartDate` date NOT NULL DEFAULT '0001-01-01',
  `CanadaInitialPayment` double NOT NULL,
  `CanadaPaymentMode` tinyint unsigned NOT NULL,
  `CanadaTreatDuration` tinyint unsigned NOT NULL,
  `CanadaNumAnticipatedPayments` tinyint unsigned NOT NULL,
  `CanadaAnticipatedPayAmount` double NOT NULL,
  `PriorAuthorizationNumber` varchar(255) NOT NULL,
  `SpecialProgramCode` tinyint NOT NULL,
  `UniformBillType` varchar(255) NOT NULL,
  `MedType` tinyint NOT NULL,
  `AdmissionTypeCode` varchar(255) NOT NULL,
  `AdmissionSourceCode` varchar(255) NOT NULL,
  `PatientStatusCode` varchar(255) NOT NULL,
  `CustomTracking` bigint NOT NULL,
  `DateResent` date NOT NULL DEFAULT '0001-01-01',
  `CorrectionType` tinyint NOT NULL,
  `ClaimIdentifier` varchar(255) NOT NULL,
  `OrigRefNum` varchar(255) NOT NULL,
  `ProvOrderOverride` bigint NOT NULL,
  `OrthoTotalM` tinyint unsigned NOT NULL,
  `ShareOfCost` double NOT NULL,
  `SecUserNumEntry` bigint NOT NULL,
  `SecDateEntry` date NOT NULL DEFAULT '0001-01-01',
  `SecDateTEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `OrderingReferralNum` bigint NOT NULL,
  `DateSentOrig` date NOT NULL DEFAULT '0001-01-01',
  `DateIllnessInjuryPreg` date NOT NULL DEFAULT '0001-01-01',
  `DateIllnessInjuryPregQualifier` smallint NOT NULL,
  `DateOther` date NOT NULL DEFAULT '0001-01-01',
  `DateOtherQualifier` smallint NOT NULL,
  `IsOutsideLab` tinyint NOT NULL,
  `ResubmissionCode` tinyint NOT NULL,
  PRIMARY KEY (`ClaimNum`),
  KEY `indexPatNum` (`PatNum`),
  KEY `indexPlanNum` (`PlanNum`),
  KEY `InsSubNum` (`InsSubNum`),
  KEY `InsSubNum2` (`InsSubNum2`),
  KEY `CustomTracking` (`CustomTracking`),
  KEY `ProvOrderOverride` (`ProvOrderOverride`),
  KEY `SecUserNumEntry` (`SecUserNumEntry`),
  KEY `indexOutClaimCovering` (`PlanNum`,`ClaimStatus`,`ClaimType`,`PatNum`,`ClaimNum`,`DateService`,`ProvTreat`,`ClaimFee`,`ClinicNum`),
  KEY `OrderingReferralNum` (`OrderingReferralNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `claim`
--

LOCK TABLES `claim` WRITE;
/*!40000 ALTER TABLE `claim` DISABLE KEYS */;
/*!40000 ALTER TABLE `claim` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:31
