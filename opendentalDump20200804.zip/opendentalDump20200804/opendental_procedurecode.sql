-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `procedurecode`
--

DROP TABLE IF EXISTS `procedurecode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `procedurecode` (
  `CodeNum` bigint NOT NULL AUTO_INCREMENT,
  `ProcCode` varchar(15) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `Descript` varchar(255) DEFAULT '',
  `AbbrDesc` varchar(50) DEFAULT '',
  `ProcTime` varchar(24) DEFAULT '',
  `ProcCat` bigint NOT NULL,
  `TreatArea` tinyint unsigned NOT NULL DEFAULT '0',
  `NoBillIns` tinyint unsigned NOT NULL DEFAULT '0',
  `IsProsth` tinyint unsigned NOT NULL DEFAULT '0',
  `DefaultNote` text,
  `IsHygiene` tinyint unsigned NOT NULL DEFAULT '0',
  `GTypeNum` smallint unsigned NOT NULL DEFAULT '0',
  `AlternateCode1` varchar(15) DEFAULT '',
  `MedicalCode` varchar(15) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT '',
  `IsTaxed` tinyint unsigned NOT NULL DEFAULT '0',
  `PaintType` tinyint NOT NULL DEFAULT '0',
  `GraphicColor` int NOT NULL,
  `LaymanTerm` varchar(255) DEFAULT '',
  `IsCanadianLab` tinyint unsigned NOT NULL,
  `PreExisting` tinyint(1) NOT NULL DEFAULT '0',
  `BaseUnits` int NOT NULL,
  `SubstitutionCode` varchar(25) DEFAULT NULL,
  `SubstOnlyIf` int NOT NULL,
  `DateTStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IsMultiVisit` tinyint NOT NULL,
  `DrugNDC` varchar(255) NOT NULL,
  `RevenueCodeDefault` varchar(255) NOT NULL,
  `ProvNumDefault` bigint NOT NULL,
  `CanadaTimeUnits` double NOT NULL,
  `IsRadiology` tinyint NOT NULL,
  `DefaultClaimNote` text NOT NULL,
  `DefaultTPNote` text NOT NULL,
  `BypassGlobalLock` tinyint NOT NULL,
  `TaxCode` varchar(16) NOT NULL,
  PRIMARY KEY (`CodeNum`),
  KEY `ProcCode` (`ProcCode`),
  KEY `ProvNumDefault` (`ProvNumDefault`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `procedurecode`
--

LOCK TABLES `procedurecode` WRITE;
/*!40000 ALTER TABLE `procedurecode` DISABLE KEYS */;
INSERT INTO `procedurecode` VALUES (1,'T4528','Amalgam-1 Surf','A1','/X/',75,1,0,0,'',0,0,'','',0,5,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(2,'T4538','Amalgam-2 Surf','A2','/X/',75,1,0,0,'',0,0,'','',0,5,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(3,'T4548','Amalgam-3 Surf','A3','/X/',75,1,0,0,'',0,0,'','',0,5,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(4,'T4558','Amalgam-4 Surf or More Surfaces','A4','/X/',75,1,0,0,'',0,0,'','',0,5,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(5,'T3512','Composite-1 Surf, Anterior','C1','/X/',75,1,0,0,'',0,0,'','',0,6,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(6,'T3522','Composite-2 Surf, Anterior','C2','/X/',75,1,0,0,'',0,0,'','',0,6,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(7,'T3532','Composite-3 Surf, Anterior','C3','/X/',75,1,0,0,'',0,0,'','',0,6,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(8,'T3542','Composite-4 Surf, Anterior or More Surfaces','C4','/X/',75,1,0,0,'',0,0,'','',0,6,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(9,'T5823','Composite-1 Surf, Posterior','C1(P)','/X/',75,1,0,0,'',0,0,'','',0,6,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(10,'T5833','Composite-2 Surf, Posterior','C2(P)','/X/',75,1,0,0,'',0,0,'','',0,6,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(11,'T5843','Composite-3 Surf, Posterior','C3(P)','/X/',75,1,0,0,'',0,0,'','',0,6,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(12,'T5853','Composite-4 Surf, Posterior or More Surfaces','C4(P)','/X/',75,1,0,0,'',0,0,'','',0,6,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(13,'T7956','Root Canal, Anterior','RCT-Ant','/X/',76,2,0,0,'',0,0,'','',0,3,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(14,'T7966','Root Canal, Bicuspid','RCT-Pre','/X/',76,2,0,0,'',0,0,'','',0,3,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(15,'T7976','Root Canal, Molar','RCT-Molar','/X/',76,2,0,0,'',0,0,'','',0,3,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(16,'T6245','Bridge Pontic, PFM','PontPFM','/X/',81,2,0,1,'',0,0,'','',0,10,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(17,'T6255','Bridge Retainer, PFM','RetPFM','/X/',81,2,0,1,'',0,0,'','',0,10,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(18,'T9826','Maxillary Denture','MaxDent','/X/',78,6,0,1,'',0,0,'','',0,12,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(19,'T9836','Mandibular Denture','MandDent','/X/',78,6,0,1,'',0,0,'','',0,12,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(20,'T2345','Build Up','BU','/X/',75,2,0,0,'',0,0,'','',0,4,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(21,'T6452','Post & Core','P&C','/X/',75,2,0,0,'',0,0,'','',0,4,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(22,'T6462','Root Canal,  Retreat Anterior','Retreat-Ant','/X/',76,2,0,0,'',0,0,'','',0,3,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(23,'T6472','Root Canal,  Retreat PreMolar','Retreat-Pre','/X/',76,2,0,0,'',0,0,'','',0,3,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(24,'T6482','Root Canal,  Retreat Molar','Retreat-Molar','/X/',76,2,0,0,'',0,0,'','',0,3,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(25,'T1356','Exam','Ex','/X/',73,3,0,0,'',0,0,'','',0,0,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(26,'T1546','Intraoral Periapical Film','PA','/X/',73,3,0,0,'',1,0,'','',0,0,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(27,'T1665','Panoramic','Pano','/X/',73,3,0,0,'',1,0,'','',0,0,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(28,'T1698','4 Bitewings','4-BWX','/X/',73,3,0,0,'',1,0,'','',0,0,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(29,'T1632','2 Bitewings','2-BWX','/X/',73,3,0,0,'',1,0,'','',0,0,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(30,'T3541','Prophy, Adult','Pro','/X/',74,3,0,0,'',1,0,'','',0,0,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(31,'T1254','Fluoride','Flo','/X/',74,3,0,0,'',1,0,'','',0,0,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(32,'T6531','PFM Crown','PFM','/X/',81,2,0,1,'',0,0,'','',0,8,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(33,'T6357','Extraction','Ext','/X/',82,2,0,0,'',0,0,'','',0,1,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(34,'~GRP~','Group Note','GrpNote','/X/',114,0,0,0,'',0,0,'','',0,0,0,'',0,0,0,NULL,0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(35,'N1254','Watch','Watch','/',73,2,1,0,'',0,0,'','',0,15,-16777216,'',0,0,0,'',0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(36,'N1255','Watch Surface','Watch Surface','/',73,1,1,0,'',0,0,'','',0,5,-16777216,'',0,0,0,'',0,'2016-03-03 21:03:09',0,'','',0,1,0,'','',0,''),(38,'~BAD~','Invalid procedure','Invalid procedure','/X/',87,0,0,0,'',0,0,'','',0,0,0,'',0,0,0,'',0,'2018-11-15 19:45:00',0,'','',0,0,0,'','',0,'');
/*!40000 ALTER TABLE `procedurecode` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:09
