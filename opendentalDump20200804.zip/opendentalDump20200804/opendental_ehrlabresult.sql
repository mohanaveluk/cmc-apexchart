-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ehrlabresult`
--

DROP TABLE IF EXISTS `ehrlabresult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ehrlabresult` (
  `EhrLabResultNum` bigint NOT NULL AUTO_INCREMENT,
  `EhrLabNum` bigint NOT NULL,
  `SetIdOBX` bigint NOT NULL,
  `ValueType` varchar(255) NOT NULL,
  `ObservationIdentifierID` varchar(255) NOT NULL,
  `ObservationIdentifierText` varchar(255) NOT NULL,
  `ObservationIdentifierCodeSystemName` varchar(255) NOT NULL,
  `ObservationIdentifierIDAlt` varchar(255) NOT NULL,
  `ObservationIdentifierTextAlt` varchar(255) NOT NULL,
  `ObservationIdentifierCodeSystemNameAlt` varchar(255) NOT NULL,
  `ObservationIdentifierTextOriginal` varchar(255) NOT NULL,
  `ObservationIdentifierSub` varchar(255) NOT NULL,
  `ObservationValueCodedElementID` varchar(255) NOT NULL,
  `ObservationValueCodedElementText` varchar(255) NOT NULL,
  `ObservationValueCodedElementCodeSystemName` varchar(255) NOT NULL,
  `ObservationValueCodedElementIDAlt` varchar(255) NOT NULL,
  `ObservationValueCodedElementTextAlt` varchar(255) NOT NULL,
  `ObservationValueCodedElementCodeSystemNameAlt` varchar(255) NOT NULL,
  `ObservationValueCodedElementTextOriginal` varchar(255) NOT NULL,
  `ObservationValueDateTime` varchar(255) NOT NULL,
  `ObservationValueTime` time NOT NULL DEFAULT '00:00:00',
  `ObservationValueComparator` varchar(255) NOT NULL,
  `ObservationValueNumber1` double NOT NULL,
  `ObservationValueSeparatorOrSuffix` varchar(255) NOT NULL,
  `ObservationValueNumber2` double NOT NULL,
  `ObservationValueNumeric` double NOT NULL,
  `ObservationValueText` varchar(255) NOT NULL,
  `UnitsID` varchar(255) NOT NULL,
  `UnitsText` varchar(255) NOT NULL,
  `UnitsCodeSystemName` varchar(255) NOT NULL,
  `UnitsIDAlt` varchar(255) NOT NULL,
  `UnitsTextAlt` varchar(255) NOT NULL,
  `UnitsCodeSystemNameAlt` varchar(255) NOT NULL,
  `UnitsTextOriginal` varchar(255) NOT NULL,
  `referenceRange` varchar(255) NOT NULL,
  `AbnormalFlags` varchar(255) NOT NULL,
  `ObservationResultStatus` varchar(255) NOT NULL,
  `ObservationDateTime` varchar(255) NOT NULL,
  `AnalysisDateTime` varchar(255) NOT NULL,
  `PerformingOrganizationName` varchar(255) NOT NULL,
  `PerformingOrganizationNameAssigningAuthorityNamespaceId` varchar(255) NOT NULL,
  `PerformingOrganizationNameAssigningAuthorityUniversalId` varchar(255) NOT NULL,
  `PerformingOrganizationNameAssigningAuthorityUniversalIdType` varchar(255) NOT NULL,
  `PerformingOrganizationIdentifierTypeCode` varchar(255) NOT NULL,
  `PerformingOrganizationIdentifier` varchar(255) NOT NULL,
  `PerformingOrganizationAddressStreet` varchar(255) NOT NULL,
  `PerformingOrganizationAddressOtherDesignation` varchar(255) NOT NULL,
  `PerformingOrganizationAddressCity` varchar(255) NOT NULL,
  `PerformingOrganizationAddressStateOrProvince` varchar(255) NOT NULL,
  `PerformingOrganizationAddressZipOrPostalCode` varchar(255) NOT NULL,
  `PerformingOrganizationAddressCountryCode` varchar(255) NOT NULL,
  `PerformingOrganizationAddressAddressType` varchar(255) NOT NULL,
  `PerformingOrganizationAddressCountyOrParishCode` varchar(255) NOT NULL,
  `MedicalDirectorID` varchar(255) NOT NULL,
  `MedicalDirectorLName` varchar(255) NOT NULL,
  `MedicalDirectorFName` varchar(255) NOT NULL,
  `MedicalDirectorMiddleNames` varchar(255) NOT NULL,
  `MedicalDirectorSuffix` varchar(255) NOT NULL,
  `MedicalDirectorPrefix` varchar(255) NOT NULL,
  `MedicalDirectorAssigningAuthorityNamespaceID` varchar(255) NOT NULL,
  `MedicalDirectorAssigningAuthorityUniversalID` varchar(255) NOT NULL,
  `MedicalDirectorAssigningAuthorityIDType` varchar(255) NOT NULL,
  `MedicalDirectorNameTypeCode` varchar(255) NOT NULL,
  `MedicalDirectorIdentifierTypeCode` varchar(255) NOT NULL,
  PRIMARY KEY (`EhrLabResultNum`),
  KEY `EhrLabNum` (`EhrLabNum`),
  KEY `SetIdOBX` (`SetIdOBX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ehrlabresult`
--

LOCK TABLES `ehrlabresult` WRITE;
/*!40000 ALTER TABLE `ehrlabresult` DISABLE KEYS */;
/*!40000 ALTER TABLE `ehrlabresult` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:17:42
