-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `autonotecontrol`
--

DROP TABLE IF EXISTS `autonotecontrol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `autonotecontrol` (
  `AutoNoteControlNum` bigint NOT NULL AUTO_INCREMENT,
  `Descript` varchar(50) DEFAULT NULL,
  `ControlType` varchar(50) DEFAULT NULL,
  `ControlLabel` varchar(255) DEFAULT NULL,
  `ControlOptions` text,
  PRIMARY KEY (`AutoNoteControlNum`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autonotecontrol`
--

LOCK TABLES `autonotecontrol` WRITE;
/*!40000 ALTER TABLE `autonotecontrol` DISABLE KEYS */;
INSERT INTO `autonotecontrol` VALUES (1,'Medications','MultiResponse','Medications','Zantac\r\nValium\r\nAdvair\r\nElavil'),(2,'Allergies','MultiResponse','Allergies','Amox\r\nLatex\r\nPen VK\r\nCeph\r\nErythro\r\nSulfa'),(3,'BP Pulse','Text','BP Pulse','BP:   /    Pulse:    '),(4,'Chief Complaint','MultiResponse','Enter Chief Complaint','Pain\r\nHeadache\r\nSwelling'),(5,'Carps','OneResponse','Carps','1\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8\r\n9\r\n10\r\n11\r\n12'),(6,'Materials','MultiResponse','Materials','Amalgam\r\nComposite\r\nL=Pop\r\nCuring Light\r\nDycal\r\nWedges\r\nTofflelmire\r\nClear Matrix Stripes\r\n'),(7,'PO Instruction','Text','PO Instruction','Do not chew on side where amalgam filling was placed for 24 hrs\r\nPossible sensitivity to hot and cold for up to 2 yrs'),(8,'Anesth','MultiResponse','Anesth','Lido 1:100,000 / manf\r\nSepto\r\nCarbo\r\nMeprivo\r\nTopical'),(9,'Anesthesia','MultiResponse','Anesthesia','Lido\r\nSepto'),(10,'Assess','Text','Assess',''),(11,'Color','OneResponse','Color','A\r\nB\r\nC'),(12,'Deviation','OneResponse','Deviation','Left\r\nRight\r\nNone'),(13,'Extraoral','MultiResponse','Extraoral','Asymmetry\r\nSwelling\r\nErythema\r\nPain\r\nParathesia\r\nTMJ'),(14,'Impression','OneResponse','Impression','Alginate\r\nBlu-Bite'),(15,'Intraoral','MultiResponse','Intraoral','Selling\r\nExudate\r\nErythema\r\nHemmorhage\r\nMobility\r\nOcclusion\r\nPain'),(16,'Left Muscle','OneResponse','Left Muscle','+\r\n++\r\n+++'),(17,'Pain','MultiResponse','Pain','High\r\nLow\r\nSharp\r\nThrobbing'),(18,'Patient Response','MultiResponse','Patient Response','had no questions.'),(19,'Plan','Text','Plan',''),(20,'Quad','MultiResponse','Quad','UR\r\nLR\r\nUL\r\nLL'),(21,'Radiology','MultiResponse','Radiology','PA\r\nBWX\r\nFMX\r\nPano'),(22,'Responsible party','MultiResponse','Who is legally responsible','Patient\r\nParent\r\nLegal guardian\r\nCaretaker\r\n'),(23,'Right Muscle','OneResponse','Right Muscle','+\r\n++\r\n+++'),(24,'Shade','Text','Shade',''),(25,'Temp Cement','OneResponse','Cement','Blockout\r\nEmbonte\r\nFregenol\r\nFuji\r\nTempBond'),(26,'Tooth','Text','Tooth',''),(27,'Vitals','Text','Vitals','BP:     \\  \r\nHR: \r\nTemp:     *');
/*!40000 ALTER TABLE `autonotecontrol` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:26
