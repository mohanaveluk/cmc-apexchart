-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inseditlog`
--

DROP TABLE IF EXISTS `inseditlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inseditlog` (
  `InsEditLogNum` bigint NOT NULL AUTO_INCREMENT,
  `FKey` bigint NOT NULL,
  `LogType` tinyint NOT NULL,
  `FieldName` varchar(255) NOT NULL,
  `OldValue` varchar(255) NOT NULL,
  `NewValue` varchar(255) NOT NULL,
  `UserNum` bigint NOT NULL,
  `DateTStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ParentKey` bigint NOT NULL,
  `Description` varchar(255) NOT NULL,
  PRIMARY KEY (`InsEditLogNum`),
  KEY `FKeyType` (`LogType`,`FKey`),
  KEY `UserNum` (`UserNum`),
  KEY `ParentKey` (`ParentKey`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inseditlog`
--

LOCK TABLES `inseditlog` WRITE;
/*!40000 ALTER TABLE `inseditlog` DISABLE KEYS */;
INSERT INTO `inseditlog` VALUES (1,6,1,'CarrierNum','NEW','6',1,'2019-08-07 19:18:15',0,'6 - Star Insurance'),(2,6,1,'ElectID','','963852',1,'2019-08-07 19:42:55',0,'6 - Star Insurance'),(3,5,0,'PlanNum','NEW','5',1,'2019-08-09 23:51:27',0,' - '),(4,33,2,'BenefitNum','NEW','33',1,'2019-08-09 23:51:28',5,'Diagnostic'),(5,34,2,'BenefitNum','NEW','34',1,'2019-08-09 23:51:28',5,'X-Ray'),(6,35,2,'BenefitNum','NEW','35',1,'2019-08-09 23:51:28',5,'Preventive'),(7,36,2,'BenefitNum','NEW','36',1,'2019-08-09 23:51:29',5,'Restorative'),(8,37,2,'BenefitNum','NEW','37',1,'2019-08-09 23:51:29',5,'Endo'),(9,38,2,'BenefitNum','NEW','38',1,'2019-08-09 23:51:29',5,'Perio'),(10,39,2,'BenefitNum','NEW','39',1,'2019-08-09 23:51:29',5,'Oral Surgery'),(11,40,2,'BenefitNum','NEW','40',1,'2019-08-09 23:51:29',5,'Crowns'),(12,41,2,'BenefitNum','NEW','41',1,'2019-08-09 23:51:29',5,'Prosth'),(13,42,2,'BenefitNum','NEW','42',1,'2019-08-09 23:51:29',5,'Diagnostic'),(14,43,2,'BenefitNum','NEW','43',1,'2019-08-09 23:51:29',5,'Preventive'),(15,5,0,'ClaimFormNum','0','3',1,'2019-08-09 23:51:54',0,' - '),(16,5,0,'CarrierNum','0','6',1,'2019-08-09 23:51:54',0,' - '),(17,5,0,'CobRule','Basic','Standard',1,'2019-08-09 23:51:54',0,' - '),(18,5,0,'FeeSched','0','53',1,'2019-08-09 23:52:35',0,' - '),(19,44,2,'BenefitNum','NEW','44',1,'2019-08-09 23:52:35',5,'Fluoride'),(20,45,2,'BenefitNum','NEW','45',1,'2019-08-09 23:52:36',5,''),(21,6,0,'PlanNum','NEW','6',1,'2019-08-09 23:56:47',0,' - '),(22,46,2,'BenefitNum','NEW','46',1,'2019-08-09 23:56:48',6,'Diagnostic'),(23,47,2,'BenefitNum','NEW','47',1,'2019-08-09 23:56:48',6,'X-Ray'),(24,48,2,'BenefitNum','NEW','48',1,'2019-08-09 23:56:48',6,'Preventive'),(25,49,2,'BenefitNum','NEW','49',1,'2019-08-09 23:56:49',6,'Restorative'),(26,50,2,'BenefitNum','NEW','50',1,'2019-08-09 23:56:49',6,'Endo'),(27,51,2,'BenefitNum','NEW','51',1,'2019-08-09 23:56:49',6,'Perio'),(28,52,2,'BenefitNum','NEW','52',1,'2019-08-09 23:56:49',6,'Oral Surgery'),(29,53,2,'BenefitNum','NEW','53',1,'2019-08-09 23:56:49',6,'Crowns'),(30,54,2,'BenefitNum','NEW','54',1,'2019-08-09 23:56:49',6,'Prosth'),(31,55,2,'BenefitNum','NEW','55',1,'2019-08-09 23:56:49',6,'Diagnostic'),(32,56,2,'BenefitNum','NEW','56',1,'2019-08-09 23:56:49',6,'Preventive'),(33,6,0,'ClaimFormNum','0','3',1,'2019-08-09 23:57:07',0,' - '),(34,6,0,'CarrierNum','0','6',1,'2019-08-09 23:57:07',0,' - '),(35,6,0,'CobRule','Basic','Standard',1,'2019-08-09 23:57:07',0,' - '),(36,7,0,'PlanNum','NEW','7',1,'2019-08-09 23:57:15',0,' - '),(37,57,2,'BenefitNum','NEW','57',1,'2019-08-09 23:57:16',7,'Diagnostic'),(38,58,2,'BenefitNum','NEW','58',1,'2019-08-09 23:57:16',7,'X-Ray'),(39,59,2,'BenefitNum','NEW','59',1,'2019-08-09 23:57:16',7,'Preventive'),(40,60,2,'BenefitNum','NEW','60',1,'2019-08-09 23:57:16',7,'Restorative'),(41,61,2,'BenefitNum','NEW','61',1,'2019-08-09 23:57:17',7,'Endo'),(42,62,2,'BenefitNum','NEW','62',1,'2019-08-09 23:57:17',7,'Perio'),(43,63,2,'BenefitNum','NEW','63',1,'2019-08-09 23:57:17',7,'Oral Surgery'),(44,64,2,'BenefitNum','NEW','64',1,'2019-08-09 23:57:17',7,'Crowns'),(45,65,2,'BenefitNum','NEW','65',1,'2019-08-09 23:57:17',7,'Prosth'),(46,66,2,'BenefitNum','NEW','66',1,'2019-08-09 23:57:18',7,'Diagnostic'),(47,67,2,'BenefitNum','NEW','67',1,'2019-08-09 23:57:18',7,'Preventive'),(48,7,0,'ClaimFormNum','0','3',1,'2019-08-09 23:57:30',0,' - '),(49,7,0,'CarrierNum','0','6',1,'2019-08-09 23:57:30',0,' - '),(50,7,0,'CobRule','Basic','Standard',1,'2019-08-09 23:57:30',0,' - '),(51,8,0,'PlanNum','NEW','8',1,'2019-08-10 00:14:11',0,' - '),(52,68,2,'BenefitNum','NEW','68',1,'2019-08-10 00:14:11',8,'Diagnostic'),(53,69,2,'BenefitNum','NEW','69',1,'2019-08-10 00:14:12',8,'X-Ray'),(54,70,2,'BenefitNum','NEW','70',1,'2019-08-10 00:14:12',8,'Preventive'),(55,71,2,'BenefitNum','NEW','71',1,'2019-08-10 00:14:12',8,'Restorative'),(56,72,2,'BenefitNum','NEW','72',1,'2019-08-10 00:14:12',8,'Endo'),(57,73,2,'BenefitNum','NEW','73',1,'2019-08-10 00:14:12',8,'Perio'),(58,74,2,'BenefitNum','NEW','74',1,'2019-08-10 00:14:12',8,'Oral Surgery'),(59,75,2,'BenefitNum','NEW','75',1,'2019-08-10 00:14:12',8,'Crowns'),(60,76,2,'BenefitNum','NEW','76',1,'2019-08-10 00:14:12',8,'Prosth'),(61,77,2,'BenefitNum','NEW','77',1,'2019-08-10 00:14:12',8,'Diagnostic'),(62,78,2,'BenefitNum','NEW','78',1,'2019-08-10 00:14:12',8,'Preventive'),(63,8,0,'ClaimFormNum','0','3',1,'2019-08-10 00:14:21',0,' - '),(64,8,0,'CarrierNum','0','6',1,'2019-08-10 00:14:21',0,' - '),(65,8,0,'CobRule','Basic','Standard',1,'2019-08-10 00:14:21',0,' - ');
/*!40000 ALTER TABLE `inseditlog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:19:31
