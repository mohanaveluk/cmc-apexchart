-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `DocNum` bigint NOT NULL AUTO_INCREMENT,
  `Description` varchar(255) DEFAULT '',
  `DateCreated` datetime NOT NULL,
  `DocCategory` bigint NOT NULL,
  `PatNum` bigint NOT NULL,
  `FileName` varchar(255) DEFAULT '',
  `ImgType` tinyint unsigned NOT NULL DEFAULT '0',
  `IsFlipped` tinyint unsigned NOT NULL DEFAULT '0',
  `DegreesRotated` smallint NOT NULL,
  `ToothNumbers` varchar(255) DEFAULT '',
  `Note` text,
  `SigIsTopaz` tinyint unsigned NOT NULL,
  `Signature` text,
  `CropX` int NOT NULL,
  `CropY` int NOT NULL,
  `CropW` int NOT NULL,
  `CropH` int NOT NULL,
  `WindowingMin` int NOT NULL,
  `WindowingMax` int NOT NULL,
  `MountItemNum` bigint NOT NULL,
  `DateTStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `RawBase64` mediumtext NOT NULL,
  `Thumbnail` text NOT NULL,
  `ExternalGUID` varchar(255) NOT NULL,
  `ExternalSource` varchar(255) NOT NULL,
  PRIMARY KEY (`DocNum`),
  KEY `PatNum` (`PatNum`),
  KEY `PNDC` (`PatNum`,`DocCategory`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
INSERT INTO `document` VALUES (72,'','2020-06-22 09:09:45',133,522001,'Bettie Green_1592834985.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-22 14:09:45','','','',''),(73,'','2020-06-22 10:08:08',133,3159801,'Leo Lee_1592838488.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-22 15:08:08','','','',''),(74,'','2020-06-22 10:11:41',132,522001,'GreenBettie_1592838701.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-22 15:11:41','','','',''),(75,'','2020-06-22 10:13:23',132,521501,'GordonBrandon_1592838803.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-22 15:13:23','','','',''),(76,'','2020-06-28 16:51:42',133,2,'Mark undefined Grant_1593381102.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-28 21:51:42','','','',''),(77,'','2020-06-28 19:35:35',133,2,'Mark undefined Grant_1593390935.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 00:35:36','','','',''),(78,'','2020-06-28 19:54:35',133,2,'Mark undefined Grant_1593392066.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 00:54:35','','','',''),(79,'','2020-06-28 19:59:24',133,2,'Mark undefined Grant_1593392364.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 00:59:24','','','',''),(80,'','2020-06-28 20:04:33',133,2,'Mark undefined Grant_1593392670.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 01:04:33','','','',''),(81,'','2020-06-28 20:09:19',133,2,'Mark undefined Grant_1593392959.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 01:09:19','','','',''),(82,'','2020-06-28 20:13:28',133,2,'Mark undefined Grant_1593393208.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 01:13:28','','','',''),(83,'','2020-06-28 20:40:58',133,2,'Mark undefined Grant_1593394858.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 01:40:58','','','',''),(84,'','2020-06-28 21:02:36',133,2,'MarkGrant_1593396113.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 02:02:36','','','',''),(85,'','2020-06-28 21:08:46',132,2,'GrantMark_1593396526.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 02:08:46','','','',''),(86,'','2020-06-29 00:11:04',133,3,'StewertGrant_1593407464.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 05:11:04','','','',''),(87,'','2020-06-29 00:12:01',133,3,'StewertGrant_1593407519.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 05:12:01','','','',''),(88,'','2020-06-29 01:01:57',133,3,'StewertGrant_1593410517.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 06:01:57','','','',''),(89,'','2020-06-29 01:04:33',133,1,'TeresaGrant_1593410673.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 06:04:33','','','',''),(90,'','2020-06-29 01:26:14',133,2,'MarkGrant_1593411964.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 06:26:14','','','',''),(91,'','2020-06-29 01:27:00',133,2,'MarkGrant_1593412020.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 06:27:00','','','',''),(92,'','2020-06-29 01:28:02',133,3,'StewertGrant_1593412082.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 06:28:02','','','',''),(93,'','2020-06-29 08:41:56',133,5,'SantraGrant_1593437877.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 13:41:56','','','',''),(94,'','2020-06-29 08:57:41',133,5,'SantraGrant_1593438979.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 13:57:41','','','',''),(95,'','2020-06-29 09:01:36',133,5,'SantraGrant_1593439256.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-06-29 14:01:36','','','',''),(96,'GrantSantra_1577559329.png','2019-12-28 12:56:28',136,5,'GrantSantra_1577559329.png',0,0,0,'','',0,'',0,0,0,0,0,0,0,'2020-07-05 20:01:21','','','','None'),(97,'GrantSantra_1577559638.png','2019-12-28 13:00:43',136,5,'GrantSantra_1577559638.png',0,0,0,'','',0,'',0,0,0,0,0,0,0,'2020-07-05 20:01:22','','','','None'),(98,'GrantSantra_1591846461.png','2020-06-10 22:34:21',136,5,'GrantSantra_1591846461.png',0,0,0,'','',0,'',0,0,0,0,0,0,0,'2020-07-05 20:01:22','','','','None'),(99,'','2020-07-22 20:51:59',132,5,'GrantSantra_1595469119.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-07-23 01:51:59','','','',''),(100,'','2020-07-22 20:52:44',133,2,'MarkGrant_1595469164.png',2,0,0,'',NULL,0,NULL,0,0,0,0,0,0,0,'2020-07-23 01:52:44','','','','');
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:42
