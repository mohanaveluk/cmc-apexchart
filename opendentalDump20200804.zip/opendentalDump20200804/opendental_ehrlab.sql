-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ehrlab`
--

DROP TABLE IF EXISTS `ehrlab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ehrlab` (
  `EhrLabNum` bigint NOT NULL AUTO_INCREMENT,
  `PatNum` bigint NOT NULL,
  `OrderControlCode` varchar(255) NOT NULL,
  `PlacerOrderNum` varchar(255) NOT NULL,
  `PlacerOrderNamespace` varchar(255) NOT NULL,
  `PlacerOrderUniversalID` varchar(255) NOT NULL,
  `PlacerOrderUniversalIDType` varchar(255) NOT NULL,
  `FillerOrderNum` varchar(255) NOT NULL,
  `FillerOrderNamespace` varchar(255) NOT NULL,
  `FillerOrderUniversalID` varchar(255) NOT NULL,
  `FillerOrderUniversalIDType` varchar(255) NOT NULL,
  `PlacerGroupNum` varchar(255) NOT NULL,
  `PlacerGroupNamespace` varchar(255) NOT NULL,
  `PlacerGroupUniversalID` varchar(255) NOT NULL,
  `PlacerGroupUniversalIDType` varchar(255) NOT NULL,
  `OrderingProviderID` varchar(255) NOT NULL,
  `OrderingProviderLName` varchar(255) NOT NULL,
  `OrderingProviderFName` varchar(255) NOT NULL,
  `OrderingProviderMiddleNames` varchar(255) NOT NULL,
  `OrderingProviderSuffix` varchar(255) NOT NULL,
  `OrderingProviderPrefix` varchar(255) NOT NULL,
  `OrderingProviderAssigningAuthorityNamespaceID` varchar(255) NOT NULL,
  `OrderingProviderAssigningAuthorityUniversalID` varchar(255) NOT NULL,
  `OrderingProviderAssigningAuthorityIDType` varchar(255) NOT NULL,
  `OrderingProviderNameTypeCode` varchar(255) NOT NULL,
  `OrderingProviderIdentifierTypeCode` varchar(255) NOT NULL,
  `SetIdOBR` bigint NOT NULL,
  `UsiID` varchar(255) NOT NULL,
  `UsiText` varchar(255) NOT NULL,
  `UsiCodeSystemName` varchar(255) NOT NULL,
  `UsiIDAlt` varchar(255) NOT NULL,
  `UsiTextAlt` varchar(255) NOT NULL,
  `UsiCodeSystemNameAlt` varchar(255) NOT NULL,
  `UsiTextOriginal` varchar(255) NOT NULL,
  `ObservationDateTimeStart` varchar(255) NOT NULL,
  `ObservationDateTimeEnd` varchar(255) NOT NULL,
  `SpecimenActionCode` varchar(255) NOT NULL,
  `ResultDateTime` varchar(255) NOT NULL,
  `ResultStatus` varchar(255) NOT NULL,
  `ParentObservationID` varchar(255) NOT NULL,
  `ParentObservationText` varchar(255) NOT NULL,
  `ParentObservationCodeSystemName` varchar(255) NOT NULL,
  `ParentObservationIDAlt` varchar(255) NOT NULL,
  `ParentObservationTextAlt` varchar(255) NOT NULL,
  `ParentObservationCodeSystemNameAlt` varchar(255) NOT NULL,
  `ParentObservationTextOriginal` varchar(255) NOT NULL,
  `ParentObservationSubID` varchar(255) NOT NULL,
  `ParentPlacerOrderNum` varchar(255) NOT NULL,
  `ParentPlacerOrderNamespace` varchar(255) NOT NULL,
  `ParentPlacerOrderUniversalID` varchar(255) NOT NULL,
  `ParentPlacerOrderUniversalIDType` varchar(255) NOT NULL,
  `ParentFillerOrderNum` varchar(255) NOT NULL,
  `ParentFillerOrderNamespace` varchar(255) NOT NULL,
  `ParentFillerOrderUniversalID` varchar(255) NOT NULL,
  `ParentFillerOrderUniversalIDType` varchar(255) NOT NULL,
  `ListEhrLabResultsHandlingF` tinyint NOT NULL,
  `ListEhrLabResultsHandlingN` tinyint NOT NULL,
  `TQ1SetId` bigint NOT NULL,
  `TQ1DateTimeStart` varchar(255) NOT NULL,
  `TQ1DateTimeEnd` varchar(255) NOT NULL,
  `IsCpoe` tinyint NOT NULL,
  `OriginalPIDSegment` text NOT NULL,
  PRIMARY KEY (`EhrLabNum`),
  KEY `PatNum` (`PatNum`),
  KEY `SetIdOBR` (`SetIdOBR`),
  KEY `TQ1SetId` (`TQ1SetId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ehrlab`
--

LOCK TABLES `ehrlab` WRITE;
/*!40000 ALTER TABLE `ehrlab` DISABLE KEYS */;
/*!40000 ALTER TABLE `ehrlab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:19:08
