-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `confirmationrequest`
--

DROP TABLE IF EXISTS `confirmationrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `confirmationrequest` (
  `ConfirmationRequestNum` bigint NOT NULL AUTO_INCREMENT,
  `ClinicNum` bigint NOT NULL,
  `IsForSms` tinyint NOT NULL,
  `IsForEmail` tinyint NOT NULL,
  `PatNum` bigint NOT NULL,
  `ApptNum` bigint NOT NULL,
  `PhonePat` varchar(255) NOT NULL,
  `DateTimeConfirmExpire` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `SecondsFromEntryToExpire` int NOT NULL,
  `ShortGUID` varchar(255) NOT NULL,
  `ConfirmCode` varchar(255) NOT NULL,
  `MsgTextToMobileTemplate` text NOT NULL,
  `MsgTextToMobile` text NOT NULL,
  `EmailSubjTemplate` text NOT NULL,
  `EmailSubj` text NOT NULL,
  `EmailTextTemplate` text NOT NULL,
  `EmailText` text NOT NULL,
  `DateTimeEntry` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `DateTimeConfirmTransmit` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `DateTimeRSVP` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `RSVPStatus` tinyint NOT NULL,
  `ResponseDescript` text NOT NULL,
  `GuidMessageToMobile` text NOT NULL,
  `GuidMessageFromMobile` text NOT NULL,
  `ShortGuidEmail` varchar(255) NOT NULL,
  `AptDateTimeOrig` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `TSPrior` bigint NOT NULL,
  `DoNotResend` tinyint NOT NULL,
  `SmsSentOk` tinyint NOT NULL,
  `EmailSentOk` tinyint NOT NULL,
  PRIMARY KEY (`ConfirmationRequestNum`),
  KEY `ClinicNum` (`ClinicNum`),
  KEY `PatNum` (`PatNum`),
  KEY `ApptNum` (`ApptNum`),
  KEY `TSPrior` (`TSPrior`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `confirmationrequest`
--

LOCK TABLES `confirmationrequest` WRITE;
/*!40000 ALTER TABLE `confirmationrequest` DISABLE KEYS */;
INSERT INTO `confirmationrequest` VALUES (41,0,1,0,6,26,'+19253320011','0001-01-01 00:00:00',0,'ACf7a9bd3d53dde19d7a51022b5afbb83d','','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nRichard  Worsham - appointment is on 07/06/2020 11:20 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-07-05 15:52:16','0001-01-01 00:00:00','0001-01-01 00:00:00',0,'','SM7e40fb05b5f945b28b408650181c75d1','','','2020-07-06 11:20:00',0,0,1,0),(42,0,1,0,2,31,'+12103439315','0001-01-01 00:00:00',0,'ACf7a9bd3d53dde19d7a51022b5afbb83d','','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 07/06/2020 11:40 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-07-05 15:52:53','0001-01-01 00:00:00','0001-01-01 00:00:00',0,'','SMddc3401e56d4432189d534aa427441fe','','','2020-07-06 11:40:00',0,0,1,0),(43,0,1,0,8,30,'+19253320011','0001-01-01 00:00:00',0,'ACf7a9bd3d53dde19d7a51022b5afbb83d','Confirm','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nKatheleen  Davis - appointment is on 07/06/2020 17:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-07-05 15:53:32','2020-07-05 17:10:34','0001-01-01 00:00:00',0,'','SM5af2c1f9896a4c189406052f98a27e09','SM0b275ae6eabe1f3626e3bff496f6fd14','','2020-07-06 17:00:00',0,0,1,0),(44,0,1,0,7,25,'+12103439315','0001-01-01 00:00:00',0,'ACf7a9bd3d53dde19d7a51022b5afbb83d','','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nDavid  Hester - appointment is on 07/23/2020 10:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-07-22 21:09:52','0001-01-01 00:00:00','0001-01-01 00:00:00',0,'','SM7e017b266e7344e99bcc6f34b1444e02','','','2020-07-23 10:00:00',0,0,1,0),(45,0,1,0,3,29,'+12016961029','0001-01-01 00:00:00',0,'ACf7a9bd3d53dde19d7a51022b5afbb83d','C','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 07/23/2020 13:40 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-07-22 21:10:00','2020-07-22 21:10:45','0001-01-01 00:00:00',0,'','SMa3f85163653c4fc49188355f672d7d17','SM3aed3655c16e445bb8b057b070037b53','','2020-07-23 13:40:00',0,0,1,0),(46,0,1,0,1,28,'+19253320011','0001-01-01 00:00:00',0,'ACf7a9bd3d53dde19d7a51022b5afbb83d','Confirm','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nTeresa  Grant - appointment is on 07/23/2020 15:40 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-07-22 22:10:49','2020-07-22 22:11:55','0001-01-01 00:00:00',0,'','SM9b068b8d5a9c4051b2733f02e60a519a','SM2da5cec7be196165a495b1b6a3bfdc48','','2020-07-23 15:40:00',0,0,1,0),(47,0,1,0,2,31,'+12103439315','0001-01-01 00:00:00',0,'ACdbe2a04d00639434bc8d19fc174402e8','','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-08-02 18:41:36','0001-01-01 00:00:00','0001-01-01 00:00:00',0,'','SM0c3a71d9335e43beafd3bb028bd1e750','','','2020-08-04 11:40:00',0,0,1,0),(48,0,1,0,1,28,'+19253320011','0001-01-01 00:00:00',0,'ACdbe2a04d00639434bc8d19fc174402e8','','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-08-02 18:42:26','0001-01-01 00:00:00','0001-01-01 00:00:00',0,'','SM46c44766846a43e8a8e4ee1210565caa','','','2020-08-04 15:40:00',0,0,1,0),(49,0,1,0,2,31,'+12103439315','0001-01-01 00:00:00',0,'ACdbe2a04d00639434bc8d19fc174402e8','','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-08-02 18:52:19','0001-01-01 00:00:00','0001-01-01 00:00:00',0,'','SM897c8b77c07941dd95a88d96e24f9ca3','','','2020-08-04 11:40:00',0,0,1,0),(50,0,1,0,1,28,'+19253320011','0001-01-01 00:00:00',0,'ACdbe2a04d00639434bc8d19fc174402e8','','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-08-02 18:52:20','0001-01-01 00:00:00','0001-01-01 00:00:00',0,'','SMbe9d80a86d3b47ce90ea5b2c884b705a','','','2020-08-04 15:40:00',0,0,1,0),(51,0,1,0,2,31,'+12103439315','0001-01-01 00:00:00',0,'ACdbe2a04d00639434bc8d19fc174402e8','','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-08-02 18:57:08','0001-01-01 00:00:00','0001-01-01 00:00:00',0,'','SM6e607612fab947f491e3569d122e8495','','','2020-08-04 11:40:00',0,0,1,0),(52,0,1,0,1,28,'+19253320011','0001-01-01 00:00:00',0,'ACdbe2a04d00639434bc8d19fc174402e8','','','Sent from your Twilio trial account - Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','','','','','2020-08-02 18:57:11','0001-01-01 00:00:00','0001-01-01 00:00:00',0,'','SMda1e643214bd4adb8bf63c33fcddacd7','','','2020-08-04 15:40:00',0,0,1,0);
/*!40000 ALTER TABLE `confirmationrequest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:20:07
