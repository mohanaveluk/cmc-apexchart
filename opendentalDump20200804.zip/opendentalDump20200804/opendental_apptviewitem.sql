-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apptviewitem`
--

DROP TABLE IF EXISTS `apptviewitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apptviewitem` (
  `ApptViewItemNum` bigint NOT NULL AUTO_INCREMENT,
  `ApptViewNum` bigint NOT NULL,
  `OpNum` bigint NOT NULL,
  `ProvNum` bigint NOT NULL,
  `ElementDesc` varchar(255) DEFAULT '',
  `ElementOrder` tinyint unsigned NOT NULL DEFAULT '0',
  `ElementColor` int NOT NULL DEFAULT '0',
  `ElementAlignment` tinyint NOT NULL,
  `ApptFieldDefNum` bigint NOT NULL,
  `PatFieldDefNum` bigint NOT NULL,
  PRIMARY KEY (`ApptViewItemNum`),
  KEY `OpNum` (`OpNum`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apptviewitem`
--

LOCK TABLES `apptviewitem` WRITE;
/*!40000 ALTER TABLE `apptviewitem` DISABLE KEYS */;
INSERT INTO `apptviewitem` VALUES (20,2,1,0,'',0,0,0,0,0),(21,2,2,0,'',0,0,0,0,0),(22,2,3,0,'',0,0,0,0,0),(23,2,4,0,'',0,0,0,0,0),(24,2,5,0,'',0,0,0,0,0),(25,2,6,0,'',0,0,0,0,0),(26,2,0,1,'',0,0,0,0,0),(27,2,0,2,'',0,0,0,0,0),(28,2,0,0,'PatientName',0,-16777216,0,0,0),(29,2,0,0,'PremedFlag',1,-65536,0,0,0),(30,2,0,0,'MedUrgNote',2,-65536,0,0,0),(31,2,0,0,'AddrNote',3,-65536,0,0,0),(32,2,0,0,'Lab',4,-16744448,0,0,0),(33,2,0,0,'Procs',5,-16777216,0,0,0),(34,2,0,0,'Note',6,-16777216,0,0,0),(35,2,0,0,'Provider',7,-16777216,0,0,0),(36,2,0,0,'HmPhone',8,-16777216,0,0,0),(37,3,1,0,'',0,0,0,0,0),(38,3,2,0,'',0,0,0,0,0),(39,3,3,0,'',0,0,0,0,0),(40,3,4,0,'',0,0,0,0,0),(41,3,0,1,'',0,0,0,0,0),(42,3,0,0,'PatientName',0,-16777216,0,0,0),(43,3,0,0,'Procs',1,-16777216,0,0,0),(44,3,0,0,'Note',2,-16777216,0,0,0),(45,4,5,0,'',0,0,0,0,0),(46,4,6,0,'',0,0,0,0,0),(47,4,0,2,'',0,0,0,0,0),(48,4,0,0,'PatientName',0,-16777216,0,0,0),(49,4,0,0,'Procs',1,-16777216,0,0,0),(50,4,0,0,'Note',2,-16777216,0,0,0),(51,2,0,0,'AssistantAbbr',0,-16777216,2,0,0),(52,2,0,0,'ConfirmedColor',0,-16777216,1,0,0),(53,2,0,0,'HasIns[I]',1,-1,1,0,0),(54,2,0,0,'InsToSend[!]',2,-1,1,0,0),(55,3,0,0,'AssistantAbbr',0,-16777216,2,0,0),(56,3,0,0,'ConfirmedColor',0,-16777216,1,0,0),(57,3,0,0,'HasIns[I]',1,-1,1,0,0),(58,3,0,0,'InsToSend[!]',2,-1,1,0,0),(59,4,0,0,'AssistantAbbr',0,-16777216,2,0,0),(60,4,0,0,'ConfirmedColor',0,-16777216,1,0,0),(61,4,0,0,'HasIns[I]',1,-1,1,0,0),(62,4,0,0,'InsToSend[!]',2,-1,1,0,0);
/*!40000 ALTER TABLE `apptviewitem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:19:30
