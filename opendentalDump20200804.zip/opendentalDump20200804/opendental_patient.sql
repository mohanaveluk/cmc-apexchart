-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `PatNum` bigint NOT NULL AUTO_INCREMENT,
  `LName` varchar(100) DEFAULT '',
  `FName` varchar(100) DEFAULT '',
  `MiddleI` varchar(100) DEFAULT '',
  `Preferred` varchar(100) DEFAULT '',
  `PatStatus` tinyint unsigned NOT NULL DEFAULT '0',
  `Gender` tinyint unsigned NOT NULL DEFAULT '0',
  `Position` tinyint unsigned NOT NULL DEFAULT '0',
  `Birthdate` date NOT NULL DEFAULT '0001-01-01',
  `SSN` varchar(100) DEFAULT '',
  `Address` varchar(100) DEFAULT '',
  `Address2` varchar(100) DEFAULT '',
  `City` varchar(100) DEFAULT '',
  `State` varchar(100) DEFAULT '',
  `Zip` varchar(100) DEFAULT '',
  `HmPhone` varchar(30) DEFAULT '',
  `WkPhone` varchar(30) DEFAULT '',
  `WirelessPhone` varchar(30) DEFAULT '',
  `Guarantor` bigint NOT NULL,
  `CreditType` char(1) DEFAULT '',
  `Email` varchar(100) DEFAULT '',
  `Salutation` varchar(100) DEFAULT '',
  `EstBalance` double NOT NULL DEFAULT '0',
  `PriProv` bigint NOT NULL,
  `SecProv` bigint NOT NULL,
  `FeeSched` bigint NOT NULL,
  `BillingType` bigint NOT NULL,
  `ImageFolder` varchar(100) DEFAULT '',
  `AddrNote` text,
  `FamFinUrgNote` text,
  `MedUrgNote` varchar(255) DEFAULT '',
  `ApptModNote` varchar(255) DEFAULT '',
  `StudentStatus` char(1) DEFAULT '',
  `SchoolName` varchar(255) NOT NULL,
  `ChartNumber` varchar(20) DEFAULT '',
  `MedicaidID` varchar(20) DEFAULT '',
  `Bal_0_30` double NOT NULL DEFAULT '0',
  `Bal_31_60` double NOT NULL DEFAULT '0',
  `Bal_61_90` double NOT NULL DEFAULT '0',
  `BalOver90` double NOT NULL DEFAULT '0',
  `InsEst` double NOT NULL DEFAULT '0',
  `BalTotal` double NOT NULL DEFAULT '0',
  `EmployerNum` bigint NOT NULL,
  `EmploymentNote` varchar(255) DEFAULT '',
  `County` varchar(255) DEFAULT '',
  `GradeLevel` tinyint NOT NULL DEFAULT '0',
  `Urgency` tinyint NOT NULL DEFAULT '0',
  `DateFirstVisit` date NOT NULL DEFAULT '0001-01-01',
  `ClinicNum` bigint NOT NULL,
  `HasIns` varchar(255) DEFAULT '',
  `TrophyFolder` varchar(255) DEFAULT '',
  `PlannedIsDone` tinyint unsigned NOT NULL DEFAULT '0',
  `Premed` tinyint unsigned NOT NULL,
  `Ward` varchar(255) DEFAULT '',
  `PreferConfirmMethod` tinyint unsigned NOT NULL,
  `PreferContactMethod` tinyint unsigned NOT NULL,
  `PreferRecallMethod` tinyint unsigned NOT NULL,
  `SchedBeforeTime` time DEFAULT NULL,
  `SchedAfterTime` time DEFAULT NULL,
  `SchedDayOfWeek` tinyint unsigned NOT NULL,
  `Language` varchar(100) DEFAULT '',
  `AdmitDate` date NOT NULL DEFAULT '0001-01-01',
  `Title` varchar(15) DEFAULT NULL,
  `PayPlanDue` double NOT NULL,
  `SiteNum` bigint NOT NULL,
  `DateTStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ResponsParty` bigint NOT NULL,
  `CanadianEligibilityCode` tinyint NOT NULL,
  `AskToArriveEarly` int NOT NULL,
  `PreferContactConfidential` tinyint NOT NULL,
  `SuperFamily` bigint NOT NULL,
  `TxtMsgOk` tinyint NOT NULL,
  `SmokingSnoMed` varchar(32) NOT NULL,
  `Country` varchar(255) NOT NULL,
  `DateTimeDeceased` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `BillingCycleDay` int NOT NULL DEFAULT '1',
  `SecUserNumEntry` bigint NOT NULL,
  `SecDateEntry` date NOT NULL DEFAULT '0001-01-01',
  `HasSuperBilling` tinyint NOT NULL,
  `PatNumCloneFrom` bigint NOT NULL,
  `DiscountPlanNum` bigint NOT NULL,
  PRIMARY KEY (`PatNum`),
  KEY `indexLName` (`LName`(10)),
  KEY `indexFName` (`FName`(10)),
  KEY `indexLFName` (`LName`,`FName`),
  KEY `indexGuarantor` (`Guarantor`),
  KEY `ResponsParty` (`ResponsParty`),
  KEY `SuperFamily` (`SuperFamily`),
  KEY `SiteNum` (`SiteNum`),
  KEY `PatStatus` (`PatStatus`),
  KEY `ClinicNum` (`ClinicNum`),
  KEY `Email` (`Email`),
  KEY `ChartNumber` (`ChartNumber`),
  KEY `SecUserNumEntry` (`SecUserNumEntry`),
  KEY `HmPhone` (`HmPhone`),
  KEY `WirelessPhone` (`WirelessPhone`),
  KEY `WkPhone` (`WkPhone`),
  KEY `PatNumCloneFrom` (`PatNumCloneFrom`),
  KEY `DiscountPlanNum` (`DiscountPlanNum`),
  KEY `FeeSched` (`FeeSched`),
  KEY `SecDateEntry` (`SecDateEntry`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (1,'Grant','Teresa','','',0,0,1,'0001-01-01','','','','','','','','','(925)332-0011',1,'','','',1745,1,0,0,40,'GrantTeresa1','','','','','','','','',75,75,75,1520,0,1745,0,'','',0,0,'2019-08-07',0,'I','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',1875,0,'2019-12-28 23:24:16',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2019-08-07',0,0,0),(2,'Grant','Mark','','',0,0,1,'0001-01-01','','','','','','','','','(210)343-9315',1,'','','',0,1,0,0,40,'GrantMark2','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2019-08-07',0,'I','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2019-12-28 23:24:36',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2019-08-07',0,0,0),(3,'Grant','Stewert','','',0,0,0,'1979-01-29','954874521',' 1234 Happy freeway','','San Antonio','TX','78248','','','(201)696-1029',3,'','gteresa@gmail.com','',750,1,0,0,40,'GrantStewert3','','','','','','','','',0,0,750,0,0,750,0,'','',0,0,'2019-08-09',0,'I','',0,0,'',0,3,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2019-12-28 01:40:38',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2019-08-07',0,0,0),(4,'Grant','','','',4,2,0,'0001-01-01','','','','','','','','','',4,'','','',0,1,0,0,40,'','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'0001-01-01',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2019-08-07 19:15:47',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2019-08-07',0,0,0),(5,'Grant','Santra','','',0,1,0,'0001-01-01','','','','','','','','','(925)332-0011',1,'','','',0,1,0,0,40,'GrantSantra5','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2019-08-09',0,'I','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2019-12-28 23:25:47',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2019-08-07',0,0,0),(6,'Worsham','Richard','','',0,0,1,'1965-02-22','986522336','P.O. Box 715, 7888 Erat. Av.','','Grass Valley','MI','27449','','','(925)332-0011',1,'','mohanaveluk@gmail.com','',0,1,0,0,40,'WorshamRichard6','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2007-05-05',0,'','',0,0,'',0,0,2,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-07-05 20:09:28',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-07-05',0,0,0),(7,'Hester','David','','',0,0,1,'1970-09-12','','P.O. Box 715, 7888 Erat. Av.','','Grass Valley','MI','27449','(559)288-8371','(559)288-8371','(210)343-9315',1,'','','',0,1,0,0,40,'HesterDavid7','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2019-02-26',0,'','',0,0,'',4,0,0,'00:00:00','00:00:00',0,'','0001-01-01','Mr',0,0,'2020-07-05 20:14:48',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-07-05',0,0,0),(8,'Davis','Katheleen','','',0,1,1,'1960-02-26','344454545','922-4502 Dictum St.','','Chino','Ontario','64513','(727)883-2219','(727)883-2218','(201)696-1029',1,'','Katheleen.A.Davis@spambob.com','',0,1,0,0,40,'DavisKatheleen8','','','','','F','','','',0,0,0,0,0,0,0,'','',0,0,'2020-03-18',0,'','',0,0,'',4,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-07-23 01:40:54',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2020-07-05',0,0,0),(9,'Roper','Joseph','','',0,0,1,'1987-09-18','424254213','922-4502 Dictum St.','','Chino','Ontario','64513','(727)883-2219','(727)883-2218','(925)332-0011',1,'','Joseph.S.Roper@spambob.com','',0,1,0,0,40,'RoperJoseph9','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2015-02-09',0,'','',0,0,'',4,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-07-05 20:37:47',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2020-07-05',0,0,0),(10,'Plemons','Valerie','','',0,1,1,'1949-05-17','653654566','922-4502 Dictum St.','','Chino','Ontario','64513','(727)883-2219','(727)883-2218','(210)343-9315',1,'','Valerie.A.Plemons@dodgit.com','',0,1,0,0,40,'PlemonsValerie10','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2019-10-11',0,'','',0,0,'',4,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-07-05 20:39:56',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2020-07-05',0,0,0);
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:19:28
