-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `computerpref`
--

DROP TABLE IF EXISTS `computerpref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `computerpref` (
  `ComputerPrefNum` bigint NOT NULL AUTO_INCREMENT,
  `ComputerName` varchar(64) NOT NULL,
  `GraphicsUseHardware` tinyint(1) NOT NULL DEFAULT '0',
  `GraphicsSimple` tinyint(1) NOT NULL DEFAULT '0',
  `SensorType` varchar(255) DEFAULT 'D',
  `SensorBinned` tinyint NOT NULL,
  `SensorPort` int DEFAULT '0',
  `SensorExposure` int DEFAULT '1',
  `GraphicsDoubleBuffering` tinyint NOT NULL,
  `PreferredPixelFormatNum` int DEFAULT '0',
  `AtoZpath` varchar(255) DEFAULT NULL,
  `TaskKeepListHidden` tinyint(1) NOT NULL,
  `TaskDock` int NOT NULL DEFAULT '0',
  `TaskX` int NOT NULL DEFAULT '900',
  `TaskY` int NOT NULL DEFAULT '625',
  `DirectXFormat` varchar(255) DEFAULT '',
  `ScanDocSelectSource` tinyint NOT NULL,
  `ScanDocShowOptions` tinyint NOT NULL,
  `ScanDocDuplex` tinyint NOT NULL,
  `ScanDocGrayscale` tinyint NOT NULL,
  `ScanDocResolution` int NOT NULL,
  `ScanDocQuality` tinyint unsigned NOT NULL,
  `ClinicNum` bigint NOT NULL,
  `ApptViewNum` bigint NOT NULL,
  `RecentApptView` tinyint unsigned NOT NULL,
  `PatSelectSearchMode` tinyint NOT NULL,
  `NoShowLanguage` tinyint NOT NULL,
  `NoShowDecimal` tinyint NOT NULL,
  `ComputerOS` varchar(255) NOT NULL,
  PRIMARY KEY (`ComputerPrefNum`),
  KEY `ClinicNum` (`ClinicNum`),
  KEY `ApptViewNum` (`ApptViewNum`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `computerpref`
--

LOCK TABLES `computerpref` WRITE;
/*!40000 ALTER TABLE `computerpref` DISABLE KEYS */;
INSERT INTO `computerpref` VALUES (1,'Snowflake',0,0,'D',0,0,1,0,0,'',0,0,900,625,'0;Hardware;64;D16;X8R8G8B8;FourSamples',0,0,0,0,150,40,0,0,0,0,0,0,'Win32NT');
/*!40000 ALTER TABLE `computerpref` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:19:02
