-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payplan`
--

DROP TABLE IF EXISTS `payplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payplan` (
  `PayPlanNum` bigint NOT NULL AUTO_INCREMENT,
  `PatNum` bigint NOT NULL,
  `Guarantor` bigint NOT NULL,
  `PayPlanDate` date NOT NULL DEFAULT '0000-01-01',
  `APR` double NOT NULL DEFAULT '0',
  `Note` text,
  `PlanNum` bigint NOT NULL,
  `CompletedAmt` double NOT NULL,
  `InsSubNum` bigint NOT NULL,
  `PaySchedule` tinyint NOT NULL,
  `NumberOfPayments` int NOT NULL,
  `PayAmt` double NOT NULL,
  `DownPayment` double NOT NULL,
  `IsClosed` tinyint NOT NULL,
  `Signature` text NOT NULL,
  `SigIsTopaz` tinyint NOT NULL,
  `PlanCategory` bigint NOT NULL,
  PRIMARY KEY (`PayPlanNum`),
  KEY `InsSubNum` (`InsSubNum`),
  KEY `PlanCategory` (`PlanCategory`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payplan`
--

LOCK TABLES `payplan` WRITE;
/*!40000 ALTER TABLE `payplan` DISABLE KEYS */;
INSERT INTO `payplan` VALUES (1,1,1,'2019-08-07',0,'08/07/2019 - Date of Agreement: 08/07/2019, Total Amount: 985, APR: 0, Total Cost of Loan: 98508/07/2019 - Date of Agreement: 08/07/2019, Total Amount: 985, APR: 0, Total Cost of Loan: 98508/07/2019 - Date of Agreement: 08/07/2019, Total Amount: 1643, APR: 0, Total Cost of Loan: 164308/07/2019 - Date of Agreement: 08/07/2019, Total Amount: 1643, APR: 0, Total Cost of Loan: 164308/07/2019 - Date of Agreement: 08/07/2019, Total Amount: 1743, APR: 0, Total Cost of Loan: 1743',0,130,0,0,0,75,0,0,'',0,0);
/*!40000 ALTER TABLE `payplan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:59
