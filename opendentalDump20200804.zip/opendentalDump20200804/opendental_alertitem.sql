-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alertitem`
--

DROP TABLE IF EXISTS `alertitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alertitem` (
  `AlertItemNum` bigint NOT NULL AUTO_INCREMENT,
  `ClinicNum` bigint NOT NULL,
  `Description` varchar(2000) NOT NULL,
  `Type` tinyint NOT NULL,
  `Severity` tinyint NOT NULL,
  `Actions` tinyint NOT NULL,
  `FormToOpen` tinyint NOT NULL,
  `FKey` bigint NOT NULL,
  `ItemValue` varchar(4000) NOT NULL,
  `UserNum` bigint NOT NULL,
  PRIMARY KEY (`AlertItemNum`),
  KEY `ClinicNum` (`ClinicNum`),
  KEY `FKey` (`FKey`),
  KEY `UserNum` (`UserNum`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alertitem`
--

LOCK TABLES `alertitem` WRITE;
/*!40000 ALTER TABLE `alertitem` DISABLE KEYS */;
INSERT INTO `alertitem` VALUES (1,0,'eServices can now be activated online.  Go to eServices -> Signup to activate.',0,1,7,4,0,'',0),(2,0,'Open Dental Service Error',0,1,4,0,0,'',0),(3,0,'Open Dental Service Error',0,1,4,0,0,'',0),(4,0,'The Web Sched New Pat feature now asks patients questions to verify patient information. \r\nIf you do not want these questions to be asked, go to eServices -> Web Sched -> New Pat and uncheck the \"Verify Info\" column.\r\nNo Action Required in many cases, check your new patient Web Sched on your web site to see behavior. See online manual for details.',5,1,7,6,0,'',0),(5,0,'Open Dental Service Error',0,1,13,0,0,'Failed to install OpenDentalService, try running as admin.',0),(6,0,'Open Dental Service Error',0,1,13,0,0,'Failed to install OpenDentalService, try running as admin.',0),(7,0,'Open Dental Service Error',0,1,13,0,0,'Failed to install OpenDentalService, try running as admin.',0),(8,-1,'No instance of Open Dental Service is running.',20,2,1,0,0,'',0);
/*!40000 ALTER TABLE `alertitem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:19:01
