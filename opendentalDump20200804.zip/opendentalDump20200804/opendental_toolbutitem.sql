-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `toolbutitem`
--

DROP TABLE IF EXISTS `toolbutitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `toolbutitem` (
  `ToolButItemNum` bigint NOT NULL AUTO_INCREMENT,
  `ProgramNum` bigint NOT NULL,
  `ToolBar` smallint unsigned NOT NULL DEFAULT '0',
  `ButtonText` varchar(255) DEFAULT '',
  PRIMARY KEY (`ToolButItemNum`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `toolbutitem`
--

LOCK TABLES `toolbutitem` WRITE;
/*!40000 ALTER TABLE `toolbutitem` DISABLE KEYS */;
INSERT INTO `toolbutitem` VALUES (3,7,2,'TigerView'),(4,8,2,'Apteryx'),(5,9,2,'Schick'),(6,10,2,'Dexis'),(7,11,2,'VixWin'),(8,12,2,'Trophy'),(9,13,2,'Sirona'),(10,14,2,'HouseCalls'),(11,15,2,'Planmeca'),(13,17,2,'DentForms'),(14,19,2,'DBSWin'),(15,20,2,'DentX'),(16,21,2,'Lightyear'),(17,22,2,'VixWin'),(18,23,2,'Trophy'),(19,24,2,'DentalEye'),(20,27,2,'Florida Probe'),(21,28,2,'Dr Ceph'),(23,30,2,'PerioPal'),(24,31,2,'MediaDent'),(25,32,7,'XDR'),(26,33,2,'Owandy'),(27,34,2,'Vipersoft'),(28,35,2,'DXIS'),(29,37,4,'PT Dental'),(30,38,4,'PT Update'),(31,39,2,'Digora'),(32,41,2,'Dolphin'),(33,43,2,'iCat'),(34,44,2,'Camsight'),(35,45,2,'CliniView'),(36,46,2,'EZDent'),(37,48,2,'Sopro'),(38,49,2,'Progeny'),(39,50,2,'OrthoPlex'),(40,53,2,'Cerec'),(41,54,2,'PattersonImg'),(42,55,2,'EvaSoft'),(43,56,2,'Apixia'),(44,57,2,'VixWinBase41'),(45,58,2,'MiPACS'),(46,59,2,'RayMage'),(47,60,2,'BioPAK'),(48,62,2,'ClioSoft'),(49,63,2,'Tscan'),(50,64,2,'CaptureLink'),(51,67,2,'Guru'),(52,68,2,'DentalStudio'),(53,69,2,'VistaDent'),(54,70,2,'HandyDentist'),(55,71,2,'XVWeb'),(56,72,2,'VixWinBase36'),(57,73,2,'AudaxCeph'),(58,74,2,'PandaPerio'),(59,75,7,'DemandForce'),(60,76,2,'iRYS'),(61,77,2,'visOra'),(62,78,2,'Z-Image'),(63,79,2,'SMARTDent'),(64,80,2,'Office'),(65,81,2,'Triana'),(66,82,2,'VixWinNumbered'),(67,84,2,'DentalTekSmartOfficePhone'),(68,86,2,'Scanora'),(69,88,2,'CleaRay'),(70,89,2,'Romexis'),(71,91,2,'Carestream'),(72,96,2,'NewTomNNT'),(73,97,2,'i-Dixel'),(74,98,2,'ADSTRA'),(75,16,2,'PatientGallery'),(76,102,2,'CADI'),(77,104,2,'OrthoInsight3d'),(78,106,2,'PandaPeriodAdvanced'),(79,107,7,'Midway Dental'),(80,109,0,'DXC Patient Credit Score'),(81,110,2,'Oryx'),(82,111,7,'PDMP');
/*!40000 ALTER TABLE `toolbutitem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:43
