-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `treatplan`
--

DROP TABLE IF EXISTS `treatplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `treatplan` (
  `TreatPlanNum` bigint NOT NULL AUTO_INCREMENT,
  `PatNum` bigint NOT NULL,
  `DateTP` date NOT NULL DEFAULT '0001-01-01',
  `Heading` varchar(255) DEFAULT '',
  `Note` text,
  `Signature` text,
  `SigIsTopaz` tinyint(1) NOT NULL,
  `ResponsParty` bigint NOT NULL,
  `DocNum` bigint NOT NULL,
  `TPStatus` tinyint NOT NULL,
  `SecUserNumEntry` bigint NOT NULL,
  `SecDateEntry` date NOT NULL DEFAULT '0001-01-01',
  `SecDateTEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UserNumPresenter` bigint NOT NULL,
  `TPType` tinyint NOT NULL,
  `SignaturePractice` text NOT NULL,
  `DateTSigned` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `DateTPracticeSigned` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `SignatureText` varchar(255) NOT NULL,
  `SignaturePracticeText` varchar(255) NOT NULL,
  PRIMARY KEY (`TreatPlanNum`),
  KEY `indexPatNum` (`PatNum`),
  KEY `DocNum` (`DocNum`),
  KEY `SecUserNumEntry` (`SecUserNumEntry`),
  KEY `UserNumPresenter` (`UserNumPresenter`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatplan`
--

LOCK TABLES `treatplan` WRITE;
/*!40000 ALTER TABLE `treatplan` DISABLE KEYS */;
INSERT INTO `treatplan` VALUES (1,1,'0001-01-01','General Cleaning and filling','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2019-08-07','2019-08-07 22:30:50',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(2,2,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2019-08-07','2019-08-07 19:49:29',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(3,5,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2019-08-09','2019-08-09 23:58:07',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(4,5,'2019-08-09','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,0,1,'2019-08-09','2019-08-09 23:59:47',1,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(5,3,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2019-08-09','2019-08-10 00:13:55',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(6,7,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2020-07-22','2020-07-23 02:15:33',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','','');
/*!40000 ALTER TABLE `treatplan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:14
