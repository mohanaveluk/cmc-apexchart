-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `displayreport`
--

DROP TABLE IF EXISTS `displayreport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `displayreport` (
  `DisplayReportNum` bigint NOT NULL AUTO_INCREMENT,
  `InternalName` varchar(255) NOT NULL,
  `ItemOrder` int NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Category` tinyint NOT NULL,
  `IsHidden` tinyint NOT NULL,
  `IsVisibleInSubMenu` tinyint NOT NULL,
  PRIMARY KEY (`DisplayReportNum`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `displayreport`
--

LOCK TABLES `displayreport` WRITE;
/*!40000 ALTER TABLE `displayreport` DISABLE KEYS */;
INSERT INTO `displayreport` VALUES (1,'ODToday',0,'Today',0,0,0),(2,'ODYesterday',1,'Yesterday',0,0,0),(3,'ODThisMonth',2,'This Month',0,0,0),(4,'ODLastMonth',3,'Last Month',0,0,0),(5,'ODThisYear',4,'This Year',0,0,0),(6,'ODMoreOptions',5,'More Options',0,0,0),(7,'ODAdjustments',0,'Adjustments',1,0,0),(8,'ODPayments',1,'Payments',1,0,0),(9,'ODProcedures',2,'Procedures',1,0,0),(10,'ODWriteoffs',3,'Writeoffs',1,0,0),(11,'ODIncompleteProcNotes',4,'Incomplete Procedure Notes',1,0,0),(12,'ODRoutingSlips',5,'Routing Slips',1,0,0),(13,'ODAgingAR',0,'Aging of A/R',2,0,0),(14,'ODClaimsNotSent',1,'Claims Not Sent',2,0,0),(15,'ODCapitation',2,'Capitation Utilization',2,0,0),(16,'ODFinanceCharge',3,'Finance Charge Report',2,0,0),(17,'ODOutstandingInsClaims',4,'Outstanding Insurance Claims',2,0,0),(18,'ODProcsNotBilled',5,'Procedures Not Billed to Insurance',2,0,0),(19,'ODPPOWriteoffs',6,'PPO Writeoffs',2,0,0),(20,'ODPaymentPlans',7,'Payment Plans',2,0,0),(21,'ODReceivablesBreakdown',8,'Receivables Breakdown',2,0,0),(22,'ODUnearnedIncome',9,'Unearned Income',2,0,0),(23,'ODInsuranceOverpaid',10,'Insurance Overpaid',2,0,0),(24,'ODActivePatients',0,'Active Patients',3,0,0),(25,'ODAppointments',1,'Appointments',3,0,0),(26,'ODBirthdays',2,'Birthdays',3,0,0),(27,'ODBrokenAppointments',3,'BrokenAppointments',3,0,0),(28,'ODInsurancePlans',4,'Insurance Plans',3,0,0),(29,'ODNewPatients',5,'New Patients',3,0,0),(30,'ODPatientsRaw',6,'Patients - Raw',3,0,0),(31,'ODPatientNotes',7,'Patient Notes',3,0,0),(32,'ODPrescriptions',8,'Prescriptions',3,0,0),(33,'ODProcedureCodes',9,'Procedure Codes - Fee Schedules',3,0,0),(34,'ODReferralsRaw',10,'Referrals - Raw',3,0,0),(35,'ODReferralAnalysis',11,'Referral Analysis',3,0,0),(36,'ODReferredProcTracking',12,'Referred Proc Tracking',3,0,0),(37,'ODTreatmentFinder',13,'Treatment Finder',3,0,0),(38,'ODRawScreeningData',0,'Raw Screening Data',4,0,0),(39,'ODRawPopulationData',1,'Raw Population Data',4,0,0),(40,'ODEligibilityFile',0,'Eligibility File',5,0,0),(41,'ODEncounterFile',1,'Encounter File',5,0,0),(42,'ODPresentedTreatmentProd',11,'Presented TreatPlan Production',2,0,0),(43,'ODTreatmentPresentationStats',12,'Treatment Presentation Statistics',2,0,0),(44,'ODProviderPayrollSummary',7,'Provider Payroll Summary',0,1,0),(45,'ODProviderPayrollDetailed',8,'Provider Payroll Detailed',0,1,0),(46,'ODNetProdDetailDaily',6,'Net Production Detail Daily',1,1,0),(47,'ODDentalSealantMeasure',2,'FQHC Dental Sealant Measure',4,0,0),(48,'ODInsurancePayPlansPastDue',13,'Ins Pay Plans Past Due',2,0,0),(49,'ODUnfinalizedInsPay',7,'Unfinalized Insurance Payments',1,0,0),(50,'ODPatPortionUncollected',8,'Patient Portion Uncollected',1,0,0),(51,'ODWebSchedAppointments',14,'Web Sched Appointments',3,0,0),(52,'ODInsAging',14,'Insurance Aging Report',2,0,0),(53,'ODCustomAging',15,'Custom Aging',2,0,0),(54,'ODDiscountPlan',15,'Discount Plans',3,0,0),(55,'ODProcOverpaid',16,'Procedures Overpaid',2,0,0),(56,'ODMonthlyProductionGoal',6,'Monthly Production Goal',0,0,0),(57,'ODHiddenPaySplits',16,'Hidden Payment Splits',3,0,0);
/*!40000 ALTER TABLE `displayreport` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:11
