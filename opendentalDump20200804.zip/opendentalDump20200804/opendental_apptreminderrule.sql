-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apptreminderrule`
--

DROP TABLE IF EXISTS `apptreminderrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apptreminderrule` (
  `ApptReminderRuleNum` bigint NOT NULL AUTO_INCREMENT,
  `TypeCur` tinyint NOT NULL,
  `TSPrior` bigint NOT NULL,
  `SendOrder` varchar(255) NOT NULL,
  `IsSendAll` tinyint NOT NULL,
  `TemplateSMS` text NOT NULL,
  `TemplateEmailSubject` text NOT NULL,
  `TemplateEmail` text NOT NULL,
  `ClinicNum` bigint NOT NULL,
  `TemplateSMSAggShared` text NOT NULL,
  `TemplateSMSAggPerAppt` text NOT NULL,
  `TemplateEmailSubjAggShared` text NOT NULL,
  `TemplateEmailAggShared` text NOT NULL,
  `TemplateEmailAggPerAppt` text NOT NULL,
  `DoNotSendWithin` bigint NOT NULL,
  PRIMARY KEY (`ApptReminderRuleNum`),
  KEY `TSPrior` (`TSPrior`),
  KEY `ClinicNum` (`ClinicNum`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apptreminderrule`
--

LOCK TABLES `apptreminderrule` WRITE;
/*!40000 ALTER TABLE `apptreminderrule` DISABLE KEYS */;
INSERT INTO `apptreminderrule` VALUES (1,0,0,'0,1,2',0,'[nameF],\r\nYou have an upcoming appointment on [apptDate] at [apptTime] with [practiceName] with [provName].\r\nThanks!','Appointment Reminder','Dental appointment reminder from [clinicName]:\n[nameF] is scheduled for an appointment at [apptTime] on [apptDate].\nThere is no need to reply if you are going to make this appointment, but if there is any issue please call [clinicPhone] as soon as possible.\nThanks!\r\n\r\n\r\n[EmailDisclaimer]',0,'Appointment Reminder:\n[Appts]\nIf you have questions call[ClinicPhone].','[NameF] is scheduled for [ApptTime] on [ApptDate] at [ClinicName].','Appointment Reminder','Appointment Reminder:\r\n[Appts]\r\nIf you have questions call [ClinicPhone].\r\n\r\n\r\n[EmailDisclaimer]','[NameF] is scheduled for [ApptTime] on [ApptDate] at [ClinicName].',0),(2,0,0,'0,1,2',0,'[nameF],\r\nYou have an upcoming appointment on [apptDate] at [apptTime] with [practiceName] with [provName].\r\nThanks!','Appointment Reminder','Dental appointment reminder from [clinicName]:\n[nameF] is scheduled for an appointment at [apptTime] on [apptDate].\nThere is no need to reply if you are going to make this appointment, but if there is any issue please call [clinicPhone] as soon as possible.\nThanks!\r\n\r\n\r\n[EmailDisclaimer]',0,'Appointment Reminder:\n[Appts]\nIf you have questions call[ClinicPhone].','[NameF] is scheduled for [ApptTime] on [ApptDate] at [ClinicName].','Appointment Reminder','Appointment Reminder:\r\n[Appts]\r\nIf you have questions call [ClinicPhone].\r\n\r\n\r\n[EmailDisclaimer]','[NameF] is scheduled for [ApptTime] on [ApptDate] at [ClinicName].',0);
/*!40000 ALTER TABLE `apptreminderrule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:38
