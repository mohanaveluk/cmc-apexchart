-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recall`
--

DROP TABLE IF EXISTS `recall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recall` (
  `RecallNum` bigint NOT NULL AUTO_INCREMENT,
  `PatNum` bigint NOT NULL,
  `DateDueCalc` date NOT NULL DEFAULT '0001-01-01',
  `DateDue` date NOT NULL DEFAULT '0001-01-01',
  `DatePrevious` date NOT NULL DEFAULT '0001-01-01',
  `RecallInterval` int NOT NULL DEFAULT '0',
  `RecallStatus` bigint NOT NULL,
  `Note` text,
  `IsDisabled` tinyint unsigned NOT NULL DEFAULT '0',
  `DateTStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `RecallTypeNum` bigint NOT NULL,
  `DisableUntilBalance` double NOT NULL,
  `DisableUntilDate` date NOT NULL DEFAULT '0001-01-01',
  `DateScheduled` date NOT NULL DEFAULT '0001-01-01',
  `Priority` tinyint NOT NULL,
  PRIMARY KEY (`RecallNum`),
  KEY `PatNum` (`PatNum`),
  KEY `DateDue` (`DateDue`),
  KEY `DatePrevious` (`DatePrevious`),
  KEY `IsDisabled` (`IsDisabled`),
  KEY `RecallTypeNum` (`RecallTypeNum`),
  KEY `DateScheduled` (`DateScheduled`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recall`
--

LOCK TABLES `recall` WRITE;
/*!40000 ALTER TABLE `recall` DISABLE KEYS */;
INSERT INTO `recall` VALUES (1,2,'0001-01-01','0001-01-01','0001-01-01',393216,0,'',0,'2020-07-05 20:23:46',1,0,'0001-01-01','0001-01-01',0),(2,1,'0001-01-01','0001-01-01','0001-01-01',393216,0,'',0,'2020-07-05 20:20:44',1,0,'0001-01-01','2020-07-06',0),(3,5,'0001-01-01','0001-01-01','0001-01-01',393216,0,'',0,'2020-07-05 20:25:23',1,0,'0001-01-01','2020-07-06',0),(4,3,'0001-01-01','0001-01-01','0001-01-01',393216,0,'',0,'2019-08-10 00:14:44',1,0,'0001-01-01','0001-01-01',0),(5,7,'0001-01-01','0001-01-01','0001-01-01',393216,0,'',0,'2020-07-23 02:15:02',1,0,'0001-01-01','2020-07-23',0),(6,6,'0001-01-01','0001-01-01','0001-01-01',393216,0,'',0,'2020-07-05 20:17:18',1,0,'0001-01-01','0001-01-01',0),(7,8,'0001-01-01','0001-01-01','0001-01-01',393216,0,'',0,'2020-07-05 20:22:22',1,0,'0001-01-01','0001-01-01',0),(8,10,'0001-01-01','0001-01-01','0001-01-01',393216,0,'',0,'2020-07-05 20:40:14',1,0,'0001-01-01','0001-01-01',0),(9,9,'0001-01-01','0001-01-01','0001-01-01',393216,0,'',0,'2020-07-05 20:40:40',1,0,'0001-01-01','2020-07-07',0);
/*!40000 ALTER TABLE `recall` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:27
