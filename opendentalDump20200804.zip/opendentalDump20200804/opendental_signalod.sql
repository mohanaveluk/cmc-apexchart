-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `signalod`
--

DROP TABLE IF EXISTS `signalod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `signalod` (
  `SignalNum` bigint NOT NULL AUTO_INCREMENT,
  `DateViewing` date NOT NULL DEFAULT '0001-01-01',
  `SigDateTime` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `FKey` bigint NOT NULL,
  `FKeyType` varchar(255) NOT NULL,
  `IType` tinyint NOT NULL,
  `RemoteRole` tinyint NOT NULL,
  `MsgValue` text NOT NULL,
  PRIMARY KEY (`SignalNum`),
  KEY `indexSigDateTime` (`SigDateTime`),
  KEY `FKey` (`FKey`)
) ENGINE=InnoDB AUTO_INCREMENT=278 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signalod`
--

LOCK TABLES `signalod` WRITE;
/*!40000 ALTER TABLE `signalod` DISABLE KEYS */;
INSERT INTO `signalod` VALUES (269,'0001-01-01','2020-07-22 21:14:43',0,'Undefined',5,0,''),(270,'2020-07-23','2020-07-22 21:15:06',1,'Provider',68,0,''),(271,'2020-07-23','2020-07-22 21:15:06',1,'Operatory',68,0,''),(272,'2020-07-23','2020-07-22 21:15:09',1,'Provider',68,0,''),(273,'2020-07-23','2020-07-22 21:15:09',1,'Operatory',68,0,''),(274,'2020-07-23','2020-07-22 21:15:10',1,'Provider',68,0,''),(275,'2020-07-23','2020-07-22 21:15:10',1,'Operatory',68,0,''),(276,'2020-07-23','2020-07-22 21:15:11',1,'Provider',68,0,''),(277,'2020-07-23','2020-07-22 21:15:12',1,'Operatory',68,0,'');
/*!40000 ALTER TABLE `signalod` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:19:52
