-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `autonote`
--

DROP TABLE IF EXISTS `autonote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `autonote` (
  `AutoNoteNum` bigint NOT NULL AUTO_INCREMENT,
  `AutoNoteName` varchar(50) DEFAULT NULL,
  `MainText` text,
  `Category` bigint NOT NULL,
  PRIMARY KEY (`AutoNoteNum`),
  KEY `Category` (`Category`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autonote`
--

LOCK TABLES `autonote` WRITE;
/*!40000 ALTER TABLE `autonote` DISABLE KEYS */;
INSERT INTO `autonote` VALUES (1,'Comp Exam','Medications: [Prompt:\"Medications\"]\r\nAllergies: [Prompt:\"Allergies\"]\r\nBP Pulse: [Prompt:\"BP Pulse\"]\r\nChief Complaint: [Prompt:\"Chief Complaint\"]\r\nDental Exam: Treatment plan printed.\r\nPt concerns:  [Prompt:\"PO Instruction\"]\r\n\r\nTMJ:\r\nRight Muscle:[Prompt:\"Right Muscle\"] \r\nLeft Muscle: [Prompt:\"Left Muscle\"]\r\n',0),(2,'Anterior Comp','Reviewed Med HX\r\nPt\'s CC:\r\nVitals:\r\n \r\nAnesth:  [Prompt:\"Anesth\"]\r\nCarpules:  [Prompt:\"Carps\"]\r\nMaterials Used:  [Prompt:\"Materials\"]\r\nShade: [Prompt:\"Shade\"]\r\nRemoved Decay- Advised of possible RCT in future\r\nNV:',0),(3,'Crown Prep','Pt presents today for crown on #[Prompt:\"Tooth \"]\r\nBite Registration - [Prompt:\"Impression\"]\r\nAnesthetic - [Prompt:\"Anesth\"]\r\nCarpules - [Prompt:\"Carps\"]\r\nImpression - [Prompt:\"Impression\"]\r\nTemp Material - [Prompt:\"Materials\"]\r\nShade - [Prompt:\"Color Chart\"]\r\nCement - [Prompt:\"Temp Cement\"]\r\n\r\nPARQ: possible RCT in future.\r\n\r\nNX: 2 week appt for seat.\r\n',0),(4,'Fillilng','Pt presents with:\r\nAnesthetic: [Prompt:\"Anesth\"]\r\nCarpules: [Prompt:\"Carps\"]\r\nMaterial Shade: \r\nNV:',0),(5,'Oral Surgery','Review Med HX\r\nBP taken\r\nAnesthetic:  [Prompt:\"Anesth\"]\r\nCarps: [Prompt:\"Carps\"]\r\nNV\r\nPain:[Prompt:\"Pain\"]',0),(6,'SOAP','Subjective:\r\nPatient Presents with:[Prompt:\"Chief Complaint\"]\r\nMedical history:\r\nReviewed todays\'s procedure:[Prompt:\"Responsible party\"] [Prompt:\"Patient Response\"]\r\nObjective:\r\nVitals: \r\nExtraoral: [Prompt:\"Extraoral\"]\r\nIntraoral:) [Prompt:\"Intraoral\"]\r\nRadiology:[Prompt:\"Radiology\"]\r\nAssessment:[Prompt:\"Assess\"]\r\nPlan:[Prompt:\"Plan\"]\r\nPARQ\r\nNV',0),(7,'SRP- Kelli','Review med hx\r\nPt chief complaint\r\nBP taken:  [Prompt:\"BP Pulse\"]\r\nQuad/s:   [Prompt:\"Quad\"]\r\nAnesth:  [Prompt:\"Anesth\"]\r\nCapules:  [Prompt:\"Carps\"]\r\nNV\r\nIn\r\n',0),(8,'TMJ Consult','Reviewed Med HX:\r\nPt\'s Chief concern:\r\nBP Taken:  [Prompt:\"BP Pulse\"]\r\nPain:   [Prompt:\"Pain\"]\r\nPano and Ceph and I/O photos taken.\r\nMuscle: Left:  [Prompt:\"Left Muscle\"] Right: [Prompt:\"Right Muscle\"]\r\nDeviation: [Prompt:\"Deviation\"]',0);
/*!40000 ALTER TABLE `autonote` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:18:10
