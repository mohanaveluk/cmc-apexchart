-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: opendental
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clearinghouse`
--

DROP TABLE IF EXISTS `clearinghouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clearinghouse` (
  `ClearinghouseNum` bigint NOT NULL AUTO_INCREMENT,
  `Description` varchar(255) DEFAULT '',
  `ExportPath` text,
  `Payors` text,
  `Eformat` tinyint unsigned NOT NULL DEFAULT '0',
  `ISA05` varchar(255) DEFAULT NULL,
  `SenderTIN` varchar(255) DEFAULT NULL,
  `ISA07` varchar(255) DEFAULT NULL,
  `ISA08` varchar(255) DEFAULT NULL,
  `ISA15` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT '',
  `ResponsePath` varchar(255) DEFAULT '',
  `CommBridge` tinyint unsigned NOT NULL DEFAULT '0',
  `ClientProgram` varchar(255) DEFAULT '',
  `LastBatchNumber` smallint unsigned NOT NULL DEFAULT '0',
  `ModemPort` tinyint unsigned NOT NULL DEFAULT '0',
  `LoginID` varchar(255) DEFAULT '',
  `SenderName` varchar(255) DEFAULT NULL,
  `SenderTelephone` varchar(255) DEFAULT NULL,
  `GS03` varchar(255) DEFAULT NULL,
  `ISA02` varchar(10) NOT NULL,
  `ISA04` varchar(10) NOT NULL,
  `ISA16` varchar(2) NOT NULL,
  `SeparatorData` varchar(2) NOT NULL,
  `SeparatorSegment` varchar(2) NOT NULL,
  `ClinicNum` bigint NOT NULL,
  `HqClearinghouseNum` bigint NOT NULL,
  `IsEraDownloadAllowed` tinyint NOT NULL DEFAULT '2',
  `IsClaimExportAllowed` tinyint NOT NULL DEFAULT '1',
  `IsAttachmentSendAllowed` tinyint NOT NULL,
  PRIMARY KEY (`ClearinghouseNum`),
  KEY `ClinicNum` (`ClinicNum`),
  KEY `HqClearinghouseNum` (`HqClearinghouseNum`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clearinghouse`
--

LOCK TABLES `clearinghouse` WRITE;
/*!40000 ALTER TABLE `clearinghouse` DISABLE KEYS */;
INSERT INTO `clearinghouse` VALUES (1,'Renaissance','C:\\Program Files\\Renaissance\\dotr\\upload\\','',2,'ZZ',NULL,'ZZ','','P','','',3,'C:\\Program Files\\Renaissance\\lite\\RemoteLite.exe',0,0,'',NULL,NULL,'','','','','','',0,1,2,1,0),(2,'Emdeon','C:\\WebMDClient\\Claims\\','',5,'ZZ','','ZZ','0135WCH00','P','','C:\\WebMDClient\\Mail\\',1,'C:\\Program Files\\WebMD\\WebMd_FileTransfer_ConClient.exe',0,0,'','','','0135WCH00','','','','','',0,2,2,1,0),(3,'BCBS GA','C:\\BCBS\\Upload\\','00601',5,'ZZ',NULL,'ZZ','BCBSGA','P','','C:\\BCBS\\Response\\',2,'',0,0,'',NULL,NULL,'BCBSGA','','','','','',0,3,2,1,0),(4,'RECS','C:\\Recscom\\','',5,'ZZ',NULL,'ZZ','RECS','P','','',5,'C:\\Recscom\\Recscom.exe',0,0,'',NULL,NULL,'RECS','','','','','',0,4,2,1,0),(5,'ClaimConnect','C:\\ClaimConnect\\Upload\\','',5,'ZZ',NULL,'30','330989922','P','','',4,'',0,0,'',NULL,NULL,'330989922','','','','','',0,5,2,1,0),(6,'Inmediata Health Group Corp','C:\\Inmediata\\Claims\\','',5,'30','','30','660610220','P','','C:\\Inmediata\\Reports\\',6,'C:\\Program Files\\Inmediata\\IMPlug.exe',0,0,'','','','660610220','','','','','',0,6,2,1,0),(7,'AOS Data systems','C:\\Program Files\\AOS\\','',5,'30','','30','AOS','P','','C:\\Program Files\\AOS\\',7,'C:\\Program Files\\AOS\\AOSCommunicator\\AOSCommunicator.exe',0,0,'','','','AOS','','','','','',0,7,2,1,0),(8,'Post-n-Track','C:\\PostnTrack\\Exports\\','',5,'ZZ',NULL,'ZZ','PostnTrack','P','','C:\\PostnTrack\\Reports\\',8,'',0,0,'',NULL,NULL,'PostnTrack','','','','','',0,8,2,1,0),(9,'EMS','C:\\EMS\\Exports\\','',5,'ZZ',NULL,'ZZ','EMS','P','','',0,'',0,0,'',NULL,NULL,'EMS','','','','','',0,9,2,1,0),(10,'ITRANS','C:\\CCD\\','',3,'ZZ',NULL,'ZZ','','P','','C:\\Program Files (x86)\\CDA\\ICD\\',9,'C:\\CCD\\CCD32.exe',0,0,'',NULL,NULL,'','','','','','',0,10,2,1,0),(11,'Tesia','C:\\TesiaLink\\OUT\\','',5,'ZZ','','ZZ','113504607','P','','C:\\TesiaLink\\IN\\',0,'C:\\Program Files\\TesiaLink\\TesiaLink.exe',0,0,'','','','113504607','','','','','',0,11,2,1,0),(12,'MercuryDE','C:\\MercuryDE\\Temp\\','',1,'ZZ',NULL,'ZZ','204203105','P','','C:\\MercuryDE\\Reports\\',11,'',0,0,'',NULL,NULL,'204203105','','','','','',0,12,2,1,0),(13,'ClaimX','C:\\ClaimX\\Temp\\','',5,'30',NULL,'30','351962405','P','','',12,'C:\\ProgramFiles\\ClaimX\\claimxclient.exe',0,0,'',NULL,NULL,'351962405','','','','','',0,13,2,1,0),(14,'Denti-Cal','C:\\Denti-Cal\\','',5,'ZZ','','ZZ','DENTICAL','P','','',13,'',0,0,'','','','DENTICAL','DENTICAL','NONE','22','1D','1C',0,14,2,1,0),(15,'Emdeon Medical','C:\\EmdeonMedical\\Claims\\','',6,'ZZ','','ZZ','133052274','P','','C:\\EmdeonMedical\\Reports\\',14,'',0,0,'','','','133052274','','','','','',0,15,2,1,0),(16,'Claimstream','C:\\ccd\\abc\\','000090',3,'','','','','','','',15,'C:\\ccd\\abc\\ccdws.exe',0,0,'','','','','','','','','',0,16,2,1,0),(17,'Apex','C:\\ONETOUCH\\','',5,'ZZ','870578776','ZZ','99999','P','','',0,'',0,0,'','Apex','8008409152','99999','','','','','',0,17,2,1,0),(18,'Electronic Dental Services','C:\\EDS\\Claims\\In\\','',5,'ZZ','','ZZ','EDS','P','','',0,'C:\\Program Files\\EDS\\edsbridge.exe',0,0,'','','','EDS','','','','','',0,18,2,1,0),(19,'Ramq','C:\\Ramq\\','',7,'','','','','','','',18,'',0,0,'','','','','','','','','',0,19,2,1,0);
/*!40000 ALTER TABLE `clearinghouse` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:19:50
