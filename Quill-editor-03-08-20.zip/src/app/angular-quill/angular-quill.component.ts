import { Component, OnInit, ElementRef } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';


@Component({
  selector: 'app-angular-quill',
  templateUrl: './angular-quill.component.html',
  styleUrls: ['./angular-quill.component.css']
})
export class AngularQuillComponent implements OnInit {


  editorForm: FormGroup;
  editorContent:string;

  editorStyle = {
    height: '300px',
    backgroundColor:'white'
  };  
  
  config =  {
    toolbar:[
      ['bold','italic','underline'],
      ['code-block'],
      ['image'],
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      //  [{ 'placeholder': ['[GuestName]', '[HotelName]'] }],
      ['clean']     
       
   
    ],
    
  };


  ngOnInit(){
    this.editorForm = new FormGroup({
      'editor': new FormControl(null)
    })
  }
  onSubmit(){
    this.editorContent = this.editorForm.get('editor').value;
    console.log(this.editorForm.get('editor').value);
      
    }
   
    maxLength(event){
      // console.log(event);
      if(event.editor.getLength()>1000){
        event.editor.deleteText(10,event.editor.getLength());
      }
    }

    
    
  
    
}
