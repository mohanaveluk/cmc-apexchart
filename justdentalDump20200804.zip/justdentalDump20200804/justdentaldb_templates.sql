-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `templates`
--

DROP TABLE IF EXISTS `templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `templatetypename_id` int DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `templatefor` varchar(250) DEFAULT NULL,
  `bodycontent` varchar(5000) DEFAULT NULL,
  `createdby` int DEFAULT NULL,
  `updatedby` int DEFAULT NULL,
  `createdon` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedon` datetime DEFAULT CURRENT_TIMESTAMP,
  `active` int DEFAULT '1',
  `comments` int DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `templatetypename_id` (`templatetypename_id`),
  CONSTRAINT `templatetypename_idfk_1` FOREIGN KEY (`templatetypename_id`) REFERENCES `templatetypename` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templates`
--

LOCK TABLES `templates` WRITE;
/*!40000 ALTER TABLE `templates` DISABLE KEYS */;
INSERT INTO `templates` VALUES (36,52,'New appointment is scheduled',NULL,'<p>Hi [#FirstName]&nbsp;,</p>\n<p>&nbsp;</p>\n<p>Your next appointment is scheduled on [#ApptDatetime] and please reply with either c or confirm to accept</p>\n<p>&nbsp;</p>\n<p>Thanks</p>\n<p>[#DoctorName]</p>\n<p>&nbsp;</p>',1,NULL,'2020-07-26 15:38:14','2020-07-26 15:38:14',1,1),(37,53,'Subject Name 2',NULL,'<p>Message text 2</p>',1,NULL,'2020-07-26 15:52:50','2020-07-26 15:52:50',1,1),(38,54,'Appointment scheduled',NULL,'<p>Hi [#FirstName]&nbsp;,</p>\n<p>Your next appointment is scheduled on 10/10/2020 and please reply with either c or confirm to accept</p>',1,NULL,'2020-07-26 16:21:48','2020-07-26 16:21:48',1,1),(39,55,'Template subject letter 1',NULL,'<p>Template Message letter 1</p>',1,NULL,'2020-07-26 16:30:19','2020-07-26 16:30:19',1,1),(40,56,'Welcome to Clinic',NULL,'<p>Hi [#FirstName]&nbsp;,</p>\n<p>&nbsp;</p>\n<p>Thanks for visiting our clinic. we will send you online concent document link shortly</p>\n<p>&nbsp;</p>\n<p>Thanks</p>\n<p>Dr. Hunde</p>\n<p>&nbsp;</p>',1,NULL,'2020-07-28 23:29:40','2020-07-28 23:29:40',1,1),(41,57,'New Patient',NULL,'<p>Hi <span class=\"contract mceNonEditable\" style=\"font-size: 14px; font-weight: bold; inline: block; background-color: #0058e0; color: #fff; padding: 3px 5px; border-radius: 3px;\">#employee-name</span> ,</p>\n<p>Thanks for visiting our clinic. we will send you online concent document link shortly</p>',1,NULL,'2020-07-28 23:34:34','2020-07-28 23:34:34',1,1);
/*!40000 ALTER TABLE `templates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:24:43
