-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat_message`
--

DROP TABLE IF EXISTS `chat_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_message` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` int NOT NULL,
  `patient_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `recipient_id` int NOT NULL,
  `conversation_id` varchar(10) NOT NULL,
  `conversation_dir` varchar(10) NOT NULL,
  `message` varchar(1000) DEFAULT NULL,
  `createdon` datetime DEFAULT CURRENT_TIMESTAMP,
  `createdby` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_message`
--

LOCK TABLES `chat_message` WRITE;
/*!40000 ALTER TABLE `chat_message` DISABLE KEYS */;
INSERT INTO `chat_message` VALUES (1,27,2,1,2,'1-2','u-p','Hi Mark','2020-07-05 13:41:09',1),(2,28,2,1,2,'1-2','u-p','How are you?','2020-07-05 13:44:56',1),(3,29,2,1,2,'1-2','u-p','Trying to contact you','2020-07-05 13:46:34',1),(4,30,1,1,1,'1-1','u-p','Hi','2020-07-05 13:49:29',1),(5,31,1,1,1,'1-1','p-u','Looking for an appointment','2020-07-05 13:50:01',1),(6,33,6,1,6,'1-6','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nRichard  Worsham - appointment is on 07/06/2020 11:20 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-07-05 15:52:15',1),(7,34,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 07/06/2020 11:40 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-07-05 15:52:53',1),(8,35,8,1,8,'1-8','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nKatheleen  Davis - appointment is on 07/06/2020 17:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-07-05 15:53:32',1),(9,36,6,1,6,'1-6','u-p','Hi Richard, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-07-05 16:45:14',1),(10,37,8,1,8,'1-8','u-p','please confirm','2020-07-05 16:57:45',1),(11,38,8,8,1,'1-8','p-u','Çonfirm','2020-07-05 16:58:23',1),(12,39,8,8,1,'1-8','p-u','Çonfirm','2020-07-05 17:01:37',1),(13,40,8,8,1,'1-8','p-u','Confirm','2020-07-05 17:10:34',1),(14,41,8,1,8,'1-8','u-p','Thanks for the confirmation','2020-07-05 17:13:01',1),(15,42,8,1,8,'1-8','u-p','hi','2020-07-22 20:54:59',1),(16,43,7,1,7,'1-7','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nDavid  Hester - appointment is on 07/23/2020 10:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-07-22 21:09:51',1),(17,44,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 07/23/2020 13:40 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-07-22 21:10:00',1),(18,45,3,3,1,'1-3','p-u','C','2020-07-22 21:10:45',1),(19,46,1,1,1,'1-1','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nTeresa  Grant - appointment is on 07/23/2020 15:40 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-07-22 22:10:49',1),(20,47,1,1,1,'1-1','p-u','Confirm','2020-07-22 22:11:55',1),(21,48,1,1,1,'1-1','u-p','i see that','2020-07-22 22:14:32',1),(22,49,1,1,1,'1-1','p-u','Thanks','2020-07-22 22:15:39',1),(23,50,1,1,1,'1-1','u-p','Good evening','2020-07-22 22:15:54',1),(24,51,1,1,1,'1-1','p-u','Gv','2020-07-22 22:15:59',1),(25,52,9,1,9,'1-9','u-p','Hi Joseph, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-07-29 21:37:20',1),(26,53,9,1,9,'1-9','u-p','Hi Joseph, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-07-29 21:37:24',1),(27,54,9,1,9,'1-9','u-p','Hi Joseph, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-07-29 22:50:59',1),(28,55,9,1,9,'1-9','u-p','Hi Joseph, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-07-29 22:51:01',1),(29,56,9,1,9,'1-9','u-p','Hi Joseph, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-07-29 22:57:38',1),(30,57,9,1,9,'1-9','u-p','Hi Joseph, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-07-29 22:57:53',1),(31,58,9,1,9,'1-9','u-p','Request for confirmation','2020-07-30 23:09:27',1),(32,59,9,1,9,'1-9','u-p','<p>Hi Joseph&nbsp;,</p>\n<p>Your next appointment is scheduled on 10/10/2020 and please reply with either c or confirm to accept</p>','2020-08-02 12:34:17',1),(33,60,9,1,9,'1-9','u-p','<p>Hi Joseph&nbsp;,</p>\n<p>Your next appointment is scheduled on 10/10/2020 and please reply with either c or confirm to accept</p>','2020-08-02 13:15:01',1),(34,61,9,1,9,'1-9','u-p','<p>Hi Joseph&nbsp;,</p>\n<p>Your next appointment is scheduled on 10/10/2020 and please reply with either c or confirm to accept</p>','2020-08-02 16:39:47',1),(35,62,9,1,9,'1-9','u-p','<p>Hi Joseph&nbsp;,</p>\n<p>Your next appointment is scheduled on 10/10/2020 and please reply with either c or confirm to accept</p>','2020-08-02 16:40:13',1),(36,63,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-08-02 18:22:11',1),(37,64,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-08-02 18:35:57',1),(38,65,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-08-02 18:41:32',1),(39,66,1,1,1,'1-1','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-08-02 18:42:19',1),(40,67,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-08-02 18:52:18',1),(41,68,1,1,1,'1-1','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-08-02 18:52:20',1),(42,69,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-08-02 18:57:07',1),(43,70,1,1,1,'1-1','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nundefined - appointment is on undefined. Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-08-02 18:57:11',1),(44,71,9,1,9,'1-9','u-p','<p>Hi Joseph&nbsp;,</p>\n<p>Your next appointment is scheduled on 10/10/2020 and please reply with either c or confirm to accept</p>','2020-08-02 19:13:15',1);
/*!40000 ALTER TABLE `chat_message` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04  1:24:44
